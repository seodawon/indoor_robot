package com.example.sensemart;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Objects;


public class MainActivity extends AppCompatActivity {

    private ListView martList;
    int[] martImage = {R.drawable.non_market_img,
            R.drawable.non_market_img,
            R.drawable.non_market_img,
            R.drawable.non_market_img,
            R.drawable.non_market_img,
            R.drawable.mart_image};

    Dialog dialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView(R.layout.first_screen);

        String[] martName = getResources().getStringArray(R.array.martName);
        String[] martDist = getResources().getStringArray(R.array.martDist);
        String[] martLocation = getResources().getStringArray(R.array.martLocation);

        martList = (ListView) findViewById(R.id.mart_list);

        MartAdapter adapter = new MartAdapter (this, martName, martDist, martLocation, martImage);
        martList.setAdapter(adapter);

        /* 다이얼로그 세팅 */
        dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog);
        Objects.requireNonNull(dialog.getWindow()).setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        martList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String selectedMart = martName[position];

                if (selectedMart.equals("이마트 월계점")) {
                    Intent intent = new Intent(MainActivity.this, MartCategory.class);
                    intent.putExtra("MartName", selectedMart);

                    startActivity(intent);
                }
                else{
                    customToastView("마트에 대한 정보가 없습니다.");
                }
            }
        });

        ImageButton bakest_btn = (ImageButton) findViewById(R.id.basket);

        bakest_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),Bakest.class);
                startActivity(intent);
            }
        });

    }

    private void customToastView(String s) {
        LayoutInflater inflater = getLayoutInflater();
        View layout = inflater.inflate(R.layout.toast_custom, (ViewGroup)findViewById(R.id.toast_layout_root));
        TextView textView = layout.findViewById(R.id.textboard);
        textView.setText(s);

        Toast toast = Toast.makeText(getApplicationContext(),s,Toast.LENGTH_SHORT);
        toast.setView(layout);
        toast.show();
    }

    class MartAdapter extends ArrayAdapter<String>{

        Context context;
        String[] rMartName, rMartDist,rMartLocation;
        int[] rMartImage;

        MartAdapter (Context c, String[] martName, String[] martDist, String[] martLocation, int[] martImage)
        {
            super(c,R.layout.mart_frame,R.id.mart_img, martLocation);
            this.context=c;
            this.rMartName = martName;
            this.rMartDist = martDist;
            this.rMartLocation = martLocation;
            this.rMartImage = martImage;
        }

        @NonNull
        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

            LayoutInflater layoutInflater = (LayoutInflater) getApplicationContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            View martinfo = layoutInflater.inflate(R.layout.mart_frame, parent, false);

            ImageView martImage = martinfo.findViewById(R.id.mart_img);
            TextView martName = martinfo.findViewById(R.id.mart_name);
            TextView martDist = martinfo.findViewById(R.id.mart_dist);
            TextView martLocation = martinfo.findViewById(R.id.mart_location);

            martImage.setImageResource(rMartImage[position]);
            martName.setText(rMartName[position]);
            martDist.setText(rMartDist[position]);
            martLocation.setText(rMartLocation[position]);
            return martinfo;
        }
    }
}
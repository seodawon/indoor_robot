package com.example.sensemart;

public class Mart implements Comparable<Mart> {
    private String martName, martLocation;
    private int imageResource, martDist;

    public Mart(String martName, int martDist, String martLocation, int imageResource) {
        this.martName = martName;
        this.martDist = martDist;
        this.martLocation = martLocation;
        this.imageResource = imageResource;
    }

    public String getMartName() {
        return martName;
    }

    public Integer getMartDist() {
        return martDist;
    }

    public String getMartLocation() {
        return martLocation;
    }

    public void setMartDist(int martDist) {
        this.martDist = martDist;
    }

    public int getImageResource() {
        return imageResource;
    }

    @Override
    public int compareTo(Mart other) {
        // martDist 기준으로 오름차순 정렬
        return Integer.compare(this.martDist, other.martDist);
    }
}
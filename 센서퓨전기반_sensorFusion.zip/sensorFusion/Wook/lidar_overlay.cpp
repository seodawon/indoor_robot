#include "rplidar_sdk/sdk/include/lidar_overlay.hpp"

// 각도를 라디안으로 변환하는 매크로 정의
#define DEG2RAD(x) ((x)*M_PI/180.)

namespace SensorFusion {

    // LidarOverlay 클래스의 소멸자 정의
    // LidarOverlay::~LidarOverlay() = default;

    /// LiDAR 오버레이 설정을 초기화합니다.
    /// @param lidarOverlayConfiguration 오버레이 설정을 포함한 맵
    /// @param imageWidth 카메라 이미지와 결합될 오버레이 이미지의 너비
    /// @param imageHeight 카메라 이미지와 결합될 오버레이 이미지의 높이
    void LidarOverlay::init(std::unordered_map<std::string, float> lidarOverlayConfiguration,
                       int imageWidth,
                       int imageHeight)
    {
        // 오버레이 설정, 이미지 크기를 저장
        lidarOverlayConfiguration_ = lidarOverlayConfiguration;
        imageWidth_ = imageWidth;
        imageHeight_ = imageHeight;
        // 좌표를 생성하는 함수 호출
        createFillCoordinates();
    }

    /// 카메라 이미지에 이진 섹터 LiDAR 데이터를 오버레이하고 오버레이된 이미지를 반환합니다.
    /// @param image LiDAR 데이터가 추가될 카메라 이미지
    /// @param sectorLidarData 섹터화된 LiDAR 데이터의 이진 값
    cv::Mat LidarOverlay::overlayLidarDataOnImage(const cv::Mat& image, const std::bitset<8>& sectorLidarData){
        // 섹터 LiDAR 데이터에 대한 캐시 키 생성
        int cacheKey = (int)(sectorLidarData.to_ulong());
        // 캐시에 해당 키가 존재하지 않으면 로드
        if(lidarOverlayCache_.find(cacheKey) == lidarOverlayCache_.end()){
            loadLidarOverlayCache(sectorLidarData);
        }
        cv::Mat finalImage; // 최종 이미지를 저장할 변수
        // 카메라 이미지와 LiDAR 오버레이 이미지를 가중 합성
        cv::addWeighted(image,
                        lidarOverlayConfiguration_[LIDAR_OVERLAY_CONFIG_LIDAR_OVERLAY_ALPHA_KEY],
                        lidarOverlayCache_[cacheKey],
                        1.0 - lidarOverlayConfiguration_[LIDAR_OVERLAY_CONFIG_LIDAR_OVERLAY_ALPHA_KEY],
                        0.0,
                        finalImage);
        return finalImage; // 최종 이미지 반환
    }

    /// 섹터화된 LiDAR 데이터에 해당하는 이미지를 오버레이 캐시에 로드합니다.
    /// @param sectorLidarData 섹터화된 LiDAR 데이터의 이진 값
    void LidarOverlay::loadLidarOverlayCache(const std::bitset<8>& sectorLidarData){
        // 배경 색으로 초기화된 오버레이 이미지 생성
        auto overlay = cv::Mat(imageHeight_,
                               imageWidth_,
                               CV_8UC3,
                               LIDAR_OVERLAY_CONFIG_LIDAR_OVERLAY_BACKGROUND_COLOR);
        
        // 섹터 LiDAR 데이터에 대한 캐시 키 생성
        int cacheKey = (int)(sectorLidarData.to_ulong());
        // 캐시에 해당 키가 존재하지 않으면 처리
        if(lidarOverlayCache_.find(cacheKey) == lidarOverlayCache_.end()){
            // 각 섹터에 대해 반복
            for(size_t sector_idx = 0; sector_idx < sectorLidarData.size(); sector_idx++){
                // 해당 섹터가 활성화되어 있고, 설정된 섹터 수를 초과하지 않는 경우
                if(sectorLidarData[sector_idx] && sector_idx < lidarOverlayConfiguration_[LIDAR_OVERLAY_CONFIG_LIDAR_OVERLAY_NUM_SECTORS_KEY]){
                    // 해당 섹터의 좌표로 오버레이 이미지에 색상을 채움
                    cv::fillPoly(overlay,
                                 sectorCoordinatesMap_[sector_idx],
                                 LIDAR_OVERLAY_CONFIG_LIDAR_OVERLAY_FILL_COLOR);
                }
            }
            // 오버레이 이미지에 섹터 구분 선을 그림
            drawSectorSeparatorLinesOnImage(overlay);
            // 생성된 오버레이 이미지를 캐시에 저장
            lidarOverlayCache_[cacheKey] = overlay;
        }
    }

    /// 오버레이 이미지의 높이와 너비를 기반으로 채우기 좌표를 생성합니다.
    void LidarOverlay::createFillCoordinates() {
        /*
            topLeftCorner       topRightCorner
                        p0   p12
                     _______________       
                p2  |  0 \     /  7,|  p10
                    | `   \   / ,   |
                p3  |__1_`_\ /____6_|  p9
                    |      /|\      |
                    |  2 /  |  \  5 |
                    |__/__3_|_4__\__|
                        p5         p7     
            bottomLeftCorner    bottomRightCorner
                        bottomCenter
                                        (p3 and p9 are not at center)
                                        (image not to scale)
        */  
        // 필요한 끝점을 생성하여 채우기 좌표를 설정
        centerPoint_ = cv::Point(imageWidth_/2, imageHeight_/2); // 이미지 중앙 점
        cv::Point bottomcenterPoint_ = cv::Point(imageWidth_/2, imageHeight_); // 하단 중앙 점
        cv::Point topLeftCornerPoint = cv::Point(0, 0); // 좌상단 코너
        cv::Point topRightCornerPoint = cv::Point(imageWidth_, 0); // 우상단 코너
        cv::Point bottomLeftCornerPoint = cv::Point(0, imageHeight_); // 좌하단 코너
        cv::Point bottomRightCornerPoint = cv::Point(imageWidth_, imageHeight_); // 우하단 코너
    
        // 왼쪽 절반의 점들 생성
        cv::Point p0 = cv::Point((imageWidth_/2) - tan(DEG2RAD(30)) * (imageHeight_/2), 0); // p0
        cv::Point p2 = cv::Point(0, tan(DEG2RAD(22.5)) * (imageWidth_/2)); // p2
        cv::Point p3 = cv::Point(0, (imageHeight_/2) + tan(DEG2RAD(15)) * (imageWidth_/2)); // p3
        cv::Point p5 = cv::Point((imageWidth_/2) - tan(DEG2RAD(37.5)) * (imageHeight_/2), imageHeight_); // p5
    
        // 오른쪽 절반의 점들 생성
        cv::Point p7 = cv::Point((imageWidth_/2) + tan(DEG2RAD(37.5)) * (imageHeight_/2), imageHeight_); // p7
        cv::Point p9 = cv::Point(imageWidth_, (imageHeight_/2) + tan(DEG2RAD(15)) * (imageWidth_/2)); // p9
        cv::Point p10 = cv::Point(imageWidth_, tan(DEG2RAD(22.5)) * (imageWidth_/2)); // p10
        cv::Point p12 = cv::Point((imageWidth_/2) + tan(DEG2RAD(30)) * (imageHeight_/2), 0); // p12

        // 섹터 0 - -150도에서 -112.5도
        std::vector<std::vector<cv::Point>> sector0 = {{{centerPoint_},
                         {p0},
                         {topLeftCornerPoint},
                         {p2}}};
        // 섹터 1 - -112.5도에서 -75도
        std::vector<std::vector<cv::Point>> sector1 = {{{centerPoint_},
                         {p2},
                         {p3}}};
        // 섹터 2 - -75도에서 -37.5도
        std::vector<std::vector<cv::Point>> sector2 = {{{centerPoint_},
                         {p3},
                         {bottomLeftCornerPoint},
                         {p5}}};
        // 섹터 3 - -37.5도에서 0도
        std::vector<std::vector<cv::Point>> sector3 = {{{centerPoint_},
                         {p5},
                         {bottomcenterPoint_}}};
        // 섹터 4 - 0도에서 37.5도
        std::vector<std::vector<cv::Point>> sector4 = {{{centerPoint_},
                         {p7},
                         {bottomcenterPoint_}}};
        // 섹터 5 - 37.5도에서 75도
        std::vector<std::vector<cv::Point>> sector5 = {{{centerPoint_},
                         {p9},
                         {bottomRightCornerPoint},
                         {p7}}};
        // 섹터 6 - 75도에서 112.5도
        std::vector<std::vector<cv::Point>> sector6 = {{{centerPoint_},
                         {p10},
                         {p9}}};
        // 섹터 7 - 112.5도에서 150도
        std::vector<std::vector<cv::Point>> sector7 = {{{centerPoint_},
                         {p12},
                         {topRightCornerPoint},
                         {p10}}};
    
        // 각 섹터의 좌표를 맵에 저장
        sectorCoordinatesMap_[0] = sector0;
        sectorCoordinatesMap_[1] = sector1;
        sectorCoordinatesMap_[2] = sector2;
        sectorCoordinatesMap_[3] = sector3;
        sectorCoordinatesMap_[4] = sector4;
        sectorCoordinatesMap_[5] = sector5;
        sectorCoordinatesMap_[6] = sector6;
        sectorCoordinatesMap_[7] = sector7;

        // 섹터 구분 선을 그리기 위해 섹터 끝점을 저장
        sectorEndPoints_.push_back(p0);
        sectorEndPoints_.push_back(p2);
        sectorEndPoints_.push_back(p3);
        sectorEndPoints_.push_back(p5);
        sectorEndPoints_.push_back(bottomcenterPoint_);
        sectorEndPoints_.push_back(p7);
        sectorEndPoints_.push_back(p9);
        sectorEndPoints_.push_back(p10);
        sectorEndPoints_.push_back(p12);                                                    
    }
    /// 이미지에 섹터 구분 선을 그립니다.
    /// @param image 섹터 구분 선이 그려질 오버레이 이미지
    void LidarOverlay::drawSectorSeparatorLinesOnImage(const cv::Mat& image) {
       // 섹터 끝점에 대해 반복
        for(auto endPoint : sectorEndPoints_) {
            // 중앙 점과 각 섹터 끝점을 연결하는 선을 그림
            cv::line(image, // 그려질 이미지
                     centerPoint_, // 선의 시작점 (중앙점)
                     endPoint, // 선의 끝점 (섹터 끝점)
                     LIDAR_OVERLAY_CONFIG_LIDAR_OVERLAY_LINE_COLOR, // 선의 색상
                     lidarOverlayConfiguration_[LIDAR_OVERLAY_CONFIG_LIDAR_OVERLAY_LINE_WIDTH_KEY]); // 선의 두께
        }
    }
}
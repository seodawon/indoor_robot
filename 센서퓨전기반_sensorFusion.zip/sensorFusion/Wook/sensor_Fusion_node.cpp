#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <string.h>
#include <unistd.h>
#include <iostream>
#include <opencv2/opencv.hpp>
#include <vector>

#include <sys/stat.h>          // 파일 상태에 대한 정보를 다루기 위한 헤더
#include <thread>              // 쓰레드 기능을 위한 헤더
#include <atomic>              // 원자적 데이터 타입을 위한 헤더
#include <memory>              // 스마트 포인터를 위한 헤더
#include <unordered_map>       // 해시 맵을 위한 헤더
#include <bitset>              // 비트 집합을 위한 헤더

#include "rplidar_sdk/sdk/include/sl_lidar.h" 
#include "rplidar_sdk/sdk/include/sl_lidar_driver.h"
#include "rplidar_sdk/sdk/include/lidar_overlay.hpp"   // Lidar 오버레이 기능 포함
#include "rplidar_sdk/sdk/include/utility.hpp"         // 유틸리티 함수 포함

// 라디안 값을 도로 변환하는 매크로 정의
#define RAD2DEG(x) ((x)*180./M_PI) 

// 기본 이미지 너비 및 높이 정의
#define DEFAULT_IMAGE_WIDTH 160
#define DEFAULT_IMAGE_HEIGHT 120

// 기본 Lidar 구성 정의
#define DEFAULT_LIDAR_CONFIGURATION_MIN_LIDAR_ANGLE 60.0  // Lidar의 최소 각도
#define DEFAULT_LIDAR_CONFIGURATION_MAX_LIDAR_ANGLE 300.0   // Lidar의 최대 각도
#define DEFAULT_LIDAR_CONFIGURATION_MIN_LIDAR_DIST 0.15      // Lidar의 최소 거리
#define DEFAULT_LIDAR_CONFIGURATION_MAX_LIDAR_DIST 1.0       // Lidar의 최대 거리
#define DEFAULT_LIDAR_CONFIGURATION_LIDAR_CLIPPING_DIST 1.0   // Lidar 클리핑 거리
#define DEFAULT_LIDAR_CONFIGURATION_NUM_LIDAR_VALUES 64       // Lidar 값의 수
#define DEFAULT_LIDAR_CONFIGURATION_NUM_LIDAR_SECTORS 64      // Lidar 섹터의 수
// 기본값 0 - 전처리 필요 없음
#define DEFAULT_LIDAR_CONFIGURATION_PREPROCESS_TYPE 1

// 기본 Lidar 오버레이 구성 정의
#define DEFAULT_LIDAR_OVERLAY_CONFIGURATION_MIN_LIDAR_ANGLE 150.0 // Lidar 오버레이의 최소 각도
#define DEFAULT_LIDAR_OVERLAY_CONFIGURATION_MAX_LIDAR_ANGLE 300.0   // Lidar 오버레이의 최대 각도
#define DEFAULT_LIDAR_OVERLAY_CONFIGURATION_MIN_LIDAR_DIST 0.15       // Lidar 오버레이의 최소 거리
#define DEFAULT_LIDAR_OVERLAY_CONFIGURATION_MAX_LIDAR_DIST 0.5        // Lidar 오버레이의 최대 거리
#define DEFAULT_LIDAR_OVERLAY_CONFIGURATION_NUM_LIDAR_VALUES 64        // Lidar 오버레이 값의 수
#define DEFAULT_LIDAR_OVERLAY_CONFIGURATION_NUM_LIDAR_SECTORS 8       // Lidar 오버레이 섹터의 수
// Lidar 오버레이 상수 정의
#define DEFAULT_LIDAR_OVERLAY_CONFIGURATION_LIDAR_OVERLAY_ALPHA 0.5   // 투명도 계수
#define DEFAULT_LIDAR_OVERLAY_CONFIGURATION_LIDAR_OVERLAY_LINE_WIDTH 1 // 선의 두께(px)
#define DEFAULT_LIDAR_OVERLAY_CONFIGURATION_LIDAR_OVERLAY_NUM_SECTORS 8 // 섹터의 수

using namespace SensorFusion;
using namespace sl;
using namespace cv;

// Lidar 전처리 키를 참조하는 열거형 정의
enum LidarPreprocessingType {
    defaultProcessing, // 기본 처리 없음
    sector,            // Lidar 값을 섹터로 나누고 이진 값으로 변환
    numLidarPreprocessingType // 전처리 타입의 수
};

static inline void delay(sl_word_size_t ms){
    while (ms>=1000){
        usleep(1000*1000);
        ms-=1000;
    };
    if (ms!=0)
        usleep(ms*1000);
}

// 센서 구성 파일 경로 정의
const char* SENSOR_CONFIGURATION_FILE_PATH = "/opt/aws/deepracer/sensor_configuration.json"; 

// 센서 구성 파일의 키 정의
const std::string LIDAR_KEY = "lidar"; // Lidar 관련 키
const std::string LIDAR_OVERLAY_KEY = "lidar_overlay"; // Lidar 오버레이 관련 키

// 센서 융합 노드의 Lidar 구성 사전에서의 키 정의
const std::string LIDAR_CONFIG_NUM_LIDAR_VALUES_KEY = "num_values"; // Lidar 값의 수 키
const std::string LIDAR_CONFIG_MIN_LIDAR_ANGLE_KEY = "min_angle"; // 최소 각도 키
const std::string LIDAR_CONFIG_MAX_LIDAR_ANGLE_KEY = "max_angle"; // 최대 각도 키
const std::string LIDAR_CONFIG_MIN_LIDAR_DIST_KEY = "min_distance"; // 최소 거리 키
const std::string LIDAR_CONFIG_MAX_LIDAR_DIST_KEY = "max_distance"; // 최대 거리 키
const std::string LIDAR_CONFIG_NUM_LIDAR_SECTORS_KEY = "num_sectors"; // 섹터 수 키

// 센서 융합 노드의 Lidar 구성 사전에서의 추가 키 정의
const std::string LIDAR_CONFIG_LIDAR_CLIPPING_DIST_KEY = "clipping_distance"; // 클리핑 거리 키
const std::string LIDAR_CONFIG_PREPROCESS_TYPE_KEY = "preprocess_type"; // 전처리 타입 키
// LiDAR 오버레이 처리를 위한 객체
SensorFusion::LidarOverlay lidarOverlayProcessingObj_;
// 이미지의 너비
int imageWidth_;
// 이미지의 높이
int imageHeight_;
// 잘못되거나 오류가 있는 LiDAR 데이터 포인트를 대체하는 데 필요한 최대 LiDAR 거리
float maxLiDARDist_;
// 수신한 카메라 이미지의 수
size_t cameraImageCount_;
// 오버레이 이미지를 게시할지 여부를 나타내는 플래그
std::atomic<bool> enableOverlayPublish_;
// 각 센서의 최소 및 최대 값을 저장하는 해시 맵
std::unordered_map<std::string, std::unordered_map<std::string, float>> sensorConfiguration_;
// 마지막으로 수신한 LiDAR 메시지의 시간
std::chrono::steady_clock::time_point lastLidarMsgRecievedTime;
// 마지막으로 수신한 카메라 메시지의 시간
std::chrono::steady_clock::time_point lastCameraMsgRecievedTime;
// LiDAR 데이터 접근을 위한 뮤텍스
std::mutex lidarMutex_;
// LiDAR 거리 데이터를 저장할 벡터
std::vector<float> lidarData_;
// 오버레이된 LiDAR 데이터를 저장할 벡터
std::vector<float> overlayLidarData_;

void createDefaultSensorConfiguration() {
    // 기본 센서 구성 초기화
    sensorConfiguration_ = {
        {LIDAR_KEY, { // Lidar 설정 키 시작
            {LIDAR_CONFIG_MIN_LIDAR_ANGLE_KEY, DEFAULT_LIDAR_CONFIGURATION_MIN_LIDAR_ANGLE}, // 최소 각도 설정
            {LIDAR_CONFIG_MAX_LIDAR_ANGLE_KEY, DEFAULT_LIDAR_CONFIGURATION_MAX_LIDAR_ANGLE}, // 최대 각도 설정
            {LIDAR_CONFIG_MIN_LIDAR_DIST_KEY, DEFAULT_LIDAR_CONFIGURATION_MIN_LIDAR_DIST}, // 최소 거리 설정
            {LIDAR_CONFIG_MAX_LIDAR_DIST_KEY, DEFAULT_LIDAR_CONFIGURATION_MAX_LIDAR_DIST}, // 최대 거리 설정
            {LIDAR_CONFIG_LIDAR_CLIPPING_DIST_KEY, DEFAULT_LIDAR_CONFIGURATION_LIDAR_CLIPPING_DIST}, // 클리핑 거리 설정
            {LIDAR_CONFIG_NUM_LIDAR_VALUES_KEY, DEFAULT_LIDAR_CONFIGURATION_NUM_LIDAR_VALUES}, // Lidar 값의 수 설정
            {LIDAR_CONFIG_NUM_LIDAR_SECTORS_KEY, DEFAULT_LIDAR_CONFIGURATION_NUM_LIDAR_SECTORS}, // Lidar 섹터 수 설정
            {LIDAR_CONFIG_PREPROCESS_TYPE_KEY, DEFAULT_LIDAR_CONFIGURATION_PREPROCESS_TYPE} // 전처리 타입 설정
        }},
        {LIDAR_OVERLAY_KEY, { // Lidar 오버레이 설정 키 시작
            {LIDAR_OVERLAY_CONFIG_MIN_LIDAR_ANGLE_KEY, DEFAULT_LIDAR_OVERLAY_CONFIGURATION_MIN_LIDAR_ANGLE}, // 최소 각도 설정
            {LIDAR_OVERLAY_CONFIG_MAX_LIDAR_ANGLE_KEY, DEFAULT_LIDAR_OVERLAY_CONFIGURATION_MAX_LIDAR_ANGLE}, // 최대 각도 설정
            {LIDAR_OVERLAY_CONFIG_MIN_LIDAR_DIST_KEY, DEFAULT_LIDAR_OVERLAY_CONFIGURATION_MIN_LIDAR_DIST}, // 최소 거리 설정
            {LIDAR_OVERLAY_CONFIG_MAX_LIDAR_DIST_KEY, DEFAULT_LIDAR_OVERLAY_CONFIGURATION_MAX_LIDAR_DIST}, // 최대 거리 설정
            {LIDAR_OVERLAY_CONFIG_NUM_LIDAR_VALUES_KEY, DEFAULT_LIDAR_OVERLAY_CONFIGURATION_NUM_LIDAR_VALUES}, // Lidar 값의 수 설정
            {LIDAR_OVERLAY_CONFIG_NUM_LIDAR_SECTORS_KEY, DEFAULT_LIDAR_OVERLAY_CONFIGURATION_NUM_LIDAR_SECTORS}, // Lidar 오버레이 섹터 수 설정
            {LIDAR_OVERLAY_CONFIG_LIDAR_OVERLAY_ALPHA_KEY, DEFAULT_LIDAR_OVERLAY_CONFIGURATION_LIDAR_OVERLAY_ALPHA}, // 투명도 설정
            {LIDAR_OVERLAY_CONFIG_LIDAR_OVERLAY_LINE_WIDTH_KEY, DEFAULT_LIDAR_OVERLAY_CONFIGURATION_LIDAR_OVERLAY_LINE_WIDTH}, // 선 두께 설정
            {LIDAR_OVERLAY_CONFIG_LIDAR_OVERLAY_NUM_SECTORS_KEY, DEFAULT_LIDAR_OVERLAY_CONFIGURATION_LIDAR_OVERLAY_NUM_SECTORS} // 섹터 수 설정
        }}
    };
}

std::vector<float> binarySectorizeLidarData(const std::vector<float>& lidarData, size_t blockSize, float maxDist) {
    std::vector<float> sectorLidarData; // 섹터화된 LiDAR 데이터를 저장할 벡터 초기화

    // LiDAR 데이터를 블록 크기만큼 증가시키며 섹터화
    for(size_t i = 0; i < lidarData.size(); i += blockSize) {
        bool setBit = false; // 해당 섹터에서 물체가 감지되었는지 여부 초기화
        // 블록 내의 각 거리 데이터 확인
        for(size_t b = 0; b < blockSize; b++) {
            // 물체가 감지된 경우 setBit를 true로 설정
            setBit = setBit || (lidarData[i + b] < maxDist);
        }
        // 섹터화된 데이터에 1(감지됨) 또는 0(감지되지 않음) 추가
        sectorLidarData.push_back((setBit) ? 1 : 0);
    }
    return sectorLidarData; // 섹터화된 LiDAR 데이터 반환
}

void lidar_callback(Lidar msg){
    try {
        // LiDAR 메시지 수신 시간을 기록
        lastLidarMsgRecievedTime = std::chrono::steady_clock::now();

        // 오버레이 범위, 각도, LiDAR 범위, 각도를 저장할 벡터 초기화
        std::vector<float> overlayRanges, overlayDegrees, lidarRanges, lidarDegrees;

        // LiDAR 스캔 데이터 처리
        for (size_t i = 0; i < msg.ranges_angles.size(); i++) {
            // 각도 계산 (라디안에서 도로 변환)
            float degree = msg.angle_min + msg.angle_increment * i; 
            // 각도가 설정된 범위 내에 있는지 확인
            if(degree >= sensorConfiguration_[LIDAR_KEY][LIDAR_CONFIG_MIN_LIDAR_ANGLE_KEY] &&
                degree <= sensorConfiguration_[LIDAR_KEY][LIDAR_CONFIG_MAX_LIDAR_ANGLE_KEY]) {
                std::cout << "\ndegree: " << degree << "\n";
            
                // 거리 값이 무한대인 경우 최대 거리로 설정
                if(std::isinf(msg.ranges_angles[i][0])) {
                    lidarRanges.push_back(maxLiDARDist_);
                }
                else {
                    // 거리 값을 최소 및 최대 거리로 제한
                    lidarRanges.push_back(std::min(std::max(static_cast<float>(msg.ranges_angles[i][0]),
                    sensorConfiguration_[LIDAR_KEY][LIDAR_CONFIG_MIN_LIDAR_DIST_KEY]),
                    maxLiDARDist_));
                }
                // 각도 추가
                lidarDegrees.push_back(degree);
            }

            // 오버레이 범위 값을 최소 및 최대 거리로 제한
            overlayRanges.push_back(std::min(std::max(static_cast<float>(msg.ranges_angles[i][0]),
                                            sensorConfiguration_[LIDAR_OVERLAY_KEY][
                                                LIDAR_OVERLAY_CONFIG_MIN_LIDAR_DIST_KEY]),
                                            sensorConfiguration_[LIDAR_OVERLAY_KEY][
                                                LIDAR_OVERLAY_CONFIG_MAX_LIDAR_DIST_KEY]));
            // 오버레이 각도 추가
            overlayDegrees.push_back(degree);
        }

        // 원하는 LiDAR 각도 생성
        auto desiredLidarDegrees = SensorFusion::linspace(sensorConfiguration_[LIDAR_KEY][LIDAR_CONFIG_MIN_LIDAR_ANGLE_KEY],
                                            sensorConfiguration_[LIDAR_KEY][LIDAR_CONFIG_MAX_LIDAR_ANGLE_KEY],
                                            sensorConfiguration_[LIDAR_KEY][LIDAR_CONFIG_NUM_LIDAR_VALUES_KEY]);

        // 원하는 오버레이 LiDAR 각도 생성
        auto desiredOverlayLidarDegrees = SensorFusion::linspace(sensorConfiguration_[LIDAR_OVERLAY_KEY][LIDAR_OVERLAY_CONFIG_MIN_LIDAR_ANGLE_KEY],
                                                    sensorConfiguration_[LIDAR_OVERLAY_KEY][LIDAR_OVERLAY_CONFIG_MAX_LIDAR_ANGLE_KEY],
                                                    sensorConfiguration_[LIDAR_OVERLAY_KEY][LIDAR_OVERLAY_CONFIG_NUM_LIDAR_VALUES_KEY]);

        // 보간을 위한 최소/최대 LiDAR 각도 및 범위를 추가 (존재하지 않는 경우)
        if(!std::count(lidarDegrees.begin(), lidarDegrees.end(), sensorConfiguration_[LIDAR_KEY][LIDAR_CONFIG_MIN_LIDAR_ANGLE_KEY])) {
            lidarDegrees.insert(lidarDegrees.begin(), sensorConfiguration_[LIDAR_KEY][LIDAR_CONFIG_MIN_LIDAR_ANGLE_KEY]); // 최소 각도 추가
            lidarDegrees.push_back(sensorConfiguration_[LIDAR_KEY][LIDAR_CONFIG_MAX_LIDAR_ANGLE_KEY]); // 최대 각도 추가
            lidarRanges.insert(lidarRanges.begin(), maxLiDARDist_); // 최소 거리 추가
            lidarRanges.push_back(maxLiDARDist_); // 최대 거리 추가
        }
        std::cout << "\ndesiredLidarDegrees: " << desiredLidarDegrees.size() << "\nlidarDegrees: " << lidarDegrees.size()
        << "\nlidarRanges: " << lidarRanges.size() << "\n";

        std::cout << "\ndesiredOverlayLidarDegrees: " << desiredOverlayLidarDegrees.size() << "\noverlayDegrees: " << overlayDegrees.size()
        << "\noverlayRanges: " << overlayRanges.size() << "\n";

        // Lidar 데이터 접근을 위한 뮤텍스 잠금
        // std::lock_guard<std::mutex> guard(lidarMutex_);
        // 보간을 통해 LiDAR 데이터 업데이트
        lidarData_ = SensorFusion::interp(desiredLidarDegrees, lidarDegrees, lidarRanges);
        overlayLidarData_ = SensorFusion::interp(desiredOverlayLidarDegrees, overlayDegrees, overlayRanges);
    }
    catch (const std::exception &ex) {
        // 예외 발생 시 에러 로그 출력
        std::cout << "LiDAR callback failed: " << ex.what() << "\n";
    }
}


void display_pub(cv::Mat frame){
    try {

        // 섹터 오버레이 값을 저장할 비트셋 초기화
        std::bitset<8> sectorOverlayValues;

        // 디스플레이 메시지 초기화
        Mat displayMsg;
        {
            // Lidar 데이터 접근을 위한 뮤텍스 잠금
            // std::lock_guard<std::mutex> guard(lidarMutex_);

            // 오버레이 Lidar 데이터의 블록 크기 계산
            size_t blockSize = overlayLidarData_.size() / sensorConfiguration_[LIDAR_OVERLAY_KEY][LIDAR_OVERLAY_CONFIG_LIDAR_OVERLAY_NUM_SECTORS_KEY];
        
            // 블록 크기가 8인 경우 섹터화된 Lidar 데이터 생성
            if(blockSize == 8) {
                // Lidar 데이터를 이진 섹터화
                auto overlaySectorLidarData = binarySectorizeLidarData(overlayLidarData_,
                                                                        blockSize,
                                                                        sensorConfiguration_[LIDAR_OVERLAY_KEY][LIDAR_OVERLAY_CONFIG_MAX_LIDAR_DIST_KEY]);
            
                // 각 섹터의 오버레이 값을 비트셋에 저장
                for(size_t sector_idx = 0; sector_idx < overlaySectorLidarData.size(); sector_idx++) {
                    sectorOverlayValues[sector_idx] = (int)overlaySectorLidarData[sector_idx];
                }
            }
        }

        // 입력 이미지를 리사이즈할 Mat 객체 초기화
        Mat resizedImg;

        // 입력 이미지를 지정된 크기로 리사이즈
        resize(frame, resizedImg, Size(imageWidth_, imageHeight_));

        // Lidar 데이터를 이미지에 오버레이
        Mat overlayCVImage = lidarOverlayProcessingObj_.overlayLidarDataOnImage(resizedImg, sectorOverlayValues);
        
        imwrite("test1.jpg", overlayCVImage);
        std::cout << "프레임이 test.jpg로 저장되었습니다." << std::endl;
    }
    catch (const std::exception &ex) {
        // 예외 발생 시 에러 로그 출력
        std::cout << "Display callback failed: " << ex.what() << "\n";

    }
}

int main() {
    imageWidth_ = DEFAULT_IMAGE_WIDTH;   // 이미지 너비 초기화
    imageHeight_ = DEFAULT_IMAGE_HEIGHT; // 이미지 높이 초기화


    createDefaultSensorConfiguration();
    lidarOverlayProcessingObj_.init(sensorConfiguration_[LIDAR_OVERLAY_KEY], imageWidth_, imageHeight_);
    
    const char * dev = "/dev/ttyUSB0";
    unsigned int baudrate = 115200;
    unsigned int op_result;
    IChannel* channel;
    
    // 드라이버 인스턴스 생성
	ILidarDriver * drv = *createLidarDriver();
    if (!drv) {
        fprintf(stderr, "insufficent memory, exit\n");
        exit(-2);
    }

    VideoCapture cap1(0);
    if (!cap1.isOpened()) {
        std::cerr << "카메라1을 열 수 없습니다." << std::endl;
        return -1;
    } 
    
    // MJPEC 코덱 및 크기 설정
    cap1.set(CAP_PROP_FOURCC, VideoWriter::fourcc('M', 'J', 'P', 'G'));
    cap1.set(CAP_PROP_FRAME_WIDTH, 160);
    cap1.set(CAP_PROP_FRAME_HEIGHT, 120);

    // 장치 연결(/dev/ttyUSB0, 115200)
    channel = *createSerialPortChannel(dev, baudrate);
    auto res = (drv)->connect(channel);
    if (SL_IS_OK(res)) {
        // 장치 정보 출력
        sl_lidar_response_device_info_t deviceInfo;
        res = (drv)->getDeviceInfo(deviceInfo);
        if(SL_IS_OK(res)){
            printf("Model: %d, Firmware Version: %d.%d, Hardware Version: %d\n",
            deviceInfo.model,
            deviceInfo.firmware_version >> 8, deviceInfo.firmware_version & 0xffu,
            deviceInfo.hardware_version);

            printf("SLAMTEC LIDAR S/N: ");
            for (int pos = 0; pos < 16 ;++pos) {
                printf("%02X", deviceInfo.serialnum[pos]);
            }

            printf("\n"
            "Firmware Ver: %d.%02d\n"
            "Hardware Rev: %d\n"
            , deviceInfo.firmware_version>>8
            , deviceInfo.firmware_version & 0xFF
            , (int)deviceInfo.hardware_version);
        }else{
            printf("Failed to get device information from LIDAR %08x\r\n", res);
        }
    }
    
    // 스캔 시작
    drv->setMotorSpeed();
    drv->startScan(0,1);
    
    while (1) {
        // 스캔 정보 출력
        sl_lidar_response_measurement_node_hq_t nodes[8192];
        size_t   count = sizeof(nodes)/sizeof(sl_lidar_response_measurement_node_hq_t);
        Lidar lidar_data;

        op_result = drv->grabScanDataHq(nodes, count);
        
        Mat frame1;
	    std::vector<uchar> buffer1;
        cap1 >> frame1;

        if (SL_IS_OK(op_result)) {
            drv->ascendScanData(nodes, count);
            lidar_data.angle_min = 0.0;
            lidar_data.angle_increment = (float)360/(float)count;
            for (int pos = 0; pos < (int)count ; ++pos) {
                lidar_data.ranges_angles.push_back({(nodes[pos].dist_mm_q2/4.0f), (nodes[pos].angle_z_q14 * 90.f) / 16384.f});
                // std::cout << "\ndistance: " << lidar_data.ranges_angles[pos][0] << "\nangle: " << lidar_data.ranges_angles[pos][1];
            }
            std::cout << "\nangle_min: " << lidar_data.angle_min << "\nangle_increment: " << lidar_data.angle_increment << 
            "\ncount: " << count << "\n";
            lidar_callback(lidar_data);
            display_pub(frame1);
        }

    }
    // 스캔 종료
    drv->stop();
	delay(200);
    drv->setMotorSpeed(0);
    delete drv;
    drv = NULL;

    // ~LidarOverlay();

    // 카메라 해제
    cap1.release();
    destroyAllWindows();  // 모든 창 닫기 및 리소스 해제

    return 0;
}

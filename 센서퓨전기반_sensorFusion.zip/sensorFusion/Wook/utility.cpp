#include "rplidar_sdk/sdk/include/utility.hpp"

namespace SensorFusion {
    /// 주어진 파일의 존재 여부를 확인하는 함수
    /// @returns 파일이 존재하면 true, 그렇지 않으면 false
    /// @param filePath 존재 여부를 확인할 파일의 전체 경로
    bool checkFile(const std::string &filePath) {
        int fd = open(filePath.c_str(), O_RDONLY); // 파일을 읽기 전용으로 엽니다.
        close(fd); // 파일 디스크립터를 닫습니다.
        return fd >= 0; // 파일이 열렸다면 존재함을 반환
    }

    /// 주어진 센서 구성 맵을 파일에 쓰는 함수
    /// @param jsonValue 파일에 쓸 json 값
    /// @param filePath 파일에 쓸 json의 전체 경로
    void writeJSONToFile(Json::Value jsonValue, const std::string &filePath) {
        // 파일에 쓰기 위한 준비
        Json::StreamWriterBuilder builder;
        builder["commentStyle"] = "None"; // 주석 스타일 설정
        builder["indentation"] = "   "; // 들여쓰기 설정

        std::unique_ptr<Json::StreamWriter> writer(builder.newStreamWriter()); // 스트림 작성기 생성
        std::ofstream ofs(filePath); // 파일 스트림 생성
        writer->write(jsonValue, &ofs); // json 값을 파일에 씁니다.
    }

    /// 지정된 구간 사이에 균일하게 간격을 둔 숫자를 생성하는 함수
    /// @param start 시퀀스의 시작 값
    /// @param end 시퀀스의 끝 값
    /// @param num 생성할 샘플 수
    std::vector<float> linspace(float start, float end, float num)
    {
        std::vector<float> linspaced; // 결과를 저장할 벡터
        if (num == 0) { return linspaced; } // 샘플 수가 0이면 빈 벡터 반환
        if (num == 1) 
        {
            linspaced.push_back(start); // 샘플 수가 1이면 시작 값만 추가
            return linspaced;
        }
        float delta = (end - start) / (num - 1); // 간격 계산
        for(int i=0; i < num-1; ++i) // num-1번 반복하여 시작 값부터 끝 값까지 추가
        {
            linspaced.push_back(start + delta * i);
        }
        linspaced.push_back(end); // 끝 값 추가
        return linspaced; // 결과 반환
    }

    /// 단조 증가 값에 대한 1차원 보간을 생성하는 함수
    /// @param sortedX 보간을 평가할 값
    /// @param sortedXp 데이터 포인트의 X 좌표 (증가해야 함)
    /// @param sortedFp 데이터 포인트의 Y 좌표 (X와 같은 길이)
    std::vector<float> interp(const std::vector<float>& sortedX, const std::vector<float>& sortedXp, const std::vector<float>& sortedFp){
        size_t currXpIdx = 0; // 현재 sortedXp 인덱스
        size_t currXidx = 0; // 현재 sortedX 인덱스
        std::vector<float> returnArray; // 결과를 저장할 벡터
        while (currXidx < sortedX.size()) // sortedX의 모든 값에 대해 반복
        {
            // 현재 sortedX 값이 sortedXp의 두 값 사이에 있는 경우
            if (sortedXp[currXpIdx] <= sortedX[currXidx] && sortedX[currXidx] <= sortedXp[currXpIdx + 1])
            {
                // 보간 비율 계산
                const float percent = static_cast<float>(sortedX[currXidx] - sortedXp[currXpIdx]) /
                    static_cast<float>(sortedXp[currXpIdx + 1] - sortedXp[currXpIdx]);
                // 보간된 Y 값 계산 후 결과 벡터에 추가
                returnArray.push_back(sortedFp[currXpIdx] * (1.0 - percent) + sortedFp[currXpIdx + 1] * percent);
                ++currXidx; // sortedX 인덱스 증가
            }
            else
            {
                ++currXpIdx; // sortedXp 인덱스 증가
            }
        }
        return returnArray; // 결과 반환
    }
}
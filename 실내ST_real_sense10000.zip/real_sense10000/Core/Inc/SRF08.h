
#ifndef INC_SRF08_H_
#define INC_SRF08_H_

//void SRF08_COMMAND();
void SRF08_READ();
//void SRF08_CallBack();

#endif

#include "usart.h"

extern float roll, pitch, yaw;
uint8_t yaw_data[20] = {0};
char IMUdata[24] = {0};
uint8_t IMUdata_byte = 0;
uint8_t cnt = 0;


void IMU_Init(void){

	  HAL_UART_Receive_IT(&huart2, &IMUdata_byte, sizeof(IMUdata_byte)); 			// Receive IMU data 	ex)*a,b,c
}

void IMU_CallBack(){

	if(IMUdata_byte == '*') cnt = 0;												// If receive *, start from the beginning.
	else if (IMUdata_byte != '\n') IMUdata[cnt++] = (char) IMUdata_byte;			// Receive data (not *)
	else if (IMUdata_byte == '\n') {												// If receive \n, start from the beginning.
		cnt = 0;
		sscanf(IMUdata, "%f,%f,%f", &roll, &pitch, &yaw);							// IMUdata -> roll, pitch, yaw
//		sprintf(yaw_data, "yaw : %3.2f\n", yaw);									// yaw_data <- yaw
//		HAL_UART_Transmit(&huart1, IMUdata, strlen(IMUdata), HAL_MAX_DELAY); 		// Transmit IMU original data
//		HAL_UART_Transmit(&huart3, yaw_data, sizeof(yaw_data), HAL_MAX_DELAY); 		// Transmit yaw data
	}

	HAL_UART_Receive_IT(&huart2, &IMUdata_byte, sizeof(IMUdata_byte));				// Receive IMU data 	ex)*a,b,c
}

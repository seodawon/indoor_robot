/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "adc.h"
#include "crc.h"
#include "dma.h"
#include "i2c.h"
#include "rng.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "IMU.h"
#include "roboClaw.h"
#include "stm32f4xx_hal_conf.h"
#include <stdio.h>
#include "stm32f4xx_hal.h"
#include "Serial.h"
#include "ringbuffer.h"
#include "base_serial.h"
#include <string.h>
#include <stdlib.h>
#include <SRF08.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
//#define SRF08_1 0xE2
//#define SRF08_2 0xE0
#define BUFFER_SIZE 100
SERIAL_HandleTypeDef *hserial_uart5;
RoboClaw_HandleTypeDef hroboClaw1;RoboClaw_HandleTypeDef hroboClaw2;
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
uint32_t millis_count1 = 0;
bool SRF_STATE = false;
char buff_SENSOR[100] = {0};
float roll, pitch, yaw;
uint8_t UWBdata_byte = 0;
uint8_t ROSdata_byte = 0;
int num1;
float range1;
extern int Distance_State;
int PL, PR, CHECK ,check;
char bufff[50]= {0};
int count = 0;
int LEFTSPEED = 0;
int RIGHTSPEED = 0;
char buffer[10] = {0};
long MotorDelay = 100;
unsigned long MotorPreTime = 0;
unsigned long MotorCurTime;
int ROSLEEFT = 0;
int ROSRIGHT = 0;
int slowSpeed = 31;
int robot = 1;
int adcValue1;
int adcValue2;
int press = 1;
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

/////////////////////////////////////////////////////////////////////////////////////////////////
void ADC_SENSOR1(){ //압력센서 계산 함수
   HAL_ADC_Start(&hadc1);
   if (HAL_ADC_PollForConversion(&hadc1, 100) == HAL_OK) {
      adcValue1 = HAL_ADC_GetValue(&hadc1)/4;
   }
   if(adcValue1 < 150){
	   press = 1;
   }else {
	   press =0;
   }
   HAL_ADC_Stop(&hadc1);
}

void ADC_SENSOR2(){ // 압력센서 계산 함수
   HAL_ADC_Start(&hadc2);
   if (HAL_ADC_PollForConversion(&hadc2, 100) == HAL_OK) {
      adcValue2 = HAL_ADC_GetValue(&hadc2)/4;
   }
//   if(adcValue2 < 50){
//  	   press = 1;
//     }else {
//  	   press =0;
//     }
   HAL_ADC_Stop(&hadc2);
}
/////////////////////////////////////////////////////////////////////
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim) //초음파 센서 측정 시간 계산하기 위한 콜백함
{
    if(htim->Instance == TIM2)
    {
        millis_count1++;
    }
    else if (htim->Instance == TIM14) {
        HAL_IncTick();
      }
}
void millis_init1(void)
{
  HAL_TIM_Base_Start_IT(&htim2);
}
uint32_t millis1(void)
{
  return millis_count1;
}
///////////////////////////////////////////////////////////////////////////////////
//void SRF08_COMMAND1()
//{
//   long delaytime1 = 100;
//   static unsigned long pretime1 = 0;
//   unsigned long curtime1;
//   uint8_t SRF08_data_A[5] = {0x00, 0x51, 0x18, 0x25, 0x02}; //command register, cm, range register, analog gain(1025),
//   uint8_t SRF08_data_B[5] = {0x00, 0x51, 0x18, 0x25, 0x02};
//   curtime1 = millis1();
//   if(pretime1 == 0){
//   HAL_I2C_Master_Transmit(&hi2c1, SRF08_1, SRF08_data_A, sizeof(SRF08_data_A) - 1, HAL_MAX_DELAY); // command Transmit
//   HAL_I2C_Master_Transmit(&hi2c1, SRF08_2, SRF08_data_B, sizeof(SRF08_data_B) - 1, HAL_MAX_DELAY);
//      pretime1 = curtime1;
//   }
//   if ((curtime1 - pretime1) >= delaytime1){
//      pretime1 = 0;
//      HAL_I2C_Master_Transmit(&hi2c1, SRF08_1, &SRF08_data_A[4], sizeof(SRF08_data_A[4]), HAL_MAX_DELAY);
//      HAL_I2C_Master_Transmit(&hi2c1, SRF08_2, &SRF08_data_B[4], sizeof(SRF08_data_B[4]), HAL_MAX_DELAY);
//      SRF_STATE = true;
//   }
//   else{
//      SRF_STATE = false;
//   }
//}
//void SRF08_READ1()
//{
//   uint8_t SRF08_read_A[2] = {0};
//   uint8_t SRF08_read_B[2] = {0};
//   HAL_I2C_Master_Receive(&hi2c1, SRF08_1, SRF08_read_A, sizeof(SRF08_read_A), HAL_MAX_DELAY); // data Receive
//   HAL_I2C_Master_Receive(&hi2c1, SRF08_2, SRF08_read_B, sizeof(SRF08_read_B), HAL_MAX_DELAY); // data Receive
//   SRF08_Distance_A = SRF08_read_A[1] << 8;
//   SRF08_Distance_A |= SRF08_read_A[0];
//   SRF08_Distance_A = SRF08_Distance_A/256;
//   SRF08_Distance_B = SRF08_read_B[1] << 8;
//   SRF08_Distance_B |= SRF08_read_B[0];
//   SRF08_Distance_B = SRF08_Distance_B/256;
//   if((SRF08_Distance_A < 40 && SRF08_Distance_A > 0) || (SRF08_Distance_B < 40 && SRF08_Distance_B > 0)){
//      Distance_State = 1;
//   }
//   else if((SRF08_Distance_A <60 && SRF08_Distance_A >= 40) || (SRF08_Distance_B <60 && SRF08_Distance_B >= 40)){
//      Distance_State = 2;
//   }
//   else if((SRF08_Distance_A >= 60 || SRF08_Distance_A == 0) && (SRF08_Distance_B >=60 || SRF08_Distance_B == 0)){
//      Distance_State = 0;
//   }
//}
///////////////////////////////////////////////////////////////////////////////////////////
void UWB_Init(){ //UWB 값을 받는 UART 콜백
   HAL_UART_Receive_IT(&huart4, &UWBdata_byte, sizeof(UWBdata_byte));
}
void UWB_CallBack(){
   static int cnt1 = 0;
   static char UWBdata[20] = {0};
   if(UWBdata_byte == '*') cnt1 = 0;
   else if(UWBdata_byte != '\n') UWBdata[cnt1++] = (char)UWBdata_byte;
   else if(UWBdata_byte == '\n'){
      cnt1 = 0;
      sscanf(UWBdata,"%d:%f",&num1,&range1);

   }
   HAL_UART_Receive_IT(&huart4, &UWBdata_byte, sizeof(UWBdata_byte));
}
/////////////////////////////////////////////////////////////////////////////////////////s1 s2
void ROS_Init(){
   HAL_UART_Receive_IT(&huart1, &ROSdata_byte, sizeof(ROSdata_byte));
}
void ROS_CallBack(){ //ROS?  ?   받는 ?  ?
   static int cnt2 = 0;
   static char ROSdata[50]= {0}; //50
   if(ROSdata_byte == '*') cnt2 = 0;                                    // If receive *, start from the beginning.
   else if (ROSdata_byte != '\n') ROSdata[cnt2++] = (char)ROSdata_byte;         // Receive data (not *)
   else if (ROSdata_byte == '\n') {                                    // If receive \n, start from the beginning.
      cnt2 = 0;
      sscanf(ROSdata, "%d,%d,%d,%d",&PL,&PR,&CHECK,&robot); //왼쪽 모터 속도/ 오른쪽 모터 속도 / 로봇 제어 / 지금 없다. 타입 안맞는지 밀려서 아무 의미도 없는
     if(PL < 0 || PR < 0){
    	 PL = 0;
    	 PR = 0;
     }
     }
   HAL_UART_Receive_IT(&huart1, &ROSdata_byte, sizeof(ROSdata_byte));
}

/////////////////////////////////////////////////////////
int map(long x, long in_min, long in_max, long out_min, long out_max) { // ?  ?   mapping ?
    return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
}
////////////////////////////////////////////
void UpdateMotorSpeed(int targetLeftSpeed, int targetRightSpeed) { // 모터 ?  ?   천천?   증 ??   ?? ?  ?   ?  ?
    if ((LEFTSPEED < targetLeftSpeed) && (RIGHTSPEED < targetRightSpeed)) {
        if (MotorCurTime - MotorPreTime > MotorDelay) {
            LEFTSPEED += 1;
            RIGHTSPEED += 1;
            MotorPreTime = MotorCurTime;
        }
    }
    MotorControl(LEFTSPEED, RIGHTSPEED);
}
/////////////////////////////////////////////////////////////////////////////
void SlowDownMotor(int targetLeftSpeed, int targetRightSpeed) { // 모터 ?  ?   천천?   감소 ?   ?? ?  ?   ?
    if ((LEFTSPEED > slowSpeed) && (RIGHTSPEED > slowSpeed)) {
        if (MotorCurTime - MotorPreTime > MotorDelay) {
            LEFTSPEED -= 2;
            RIGHTSPEED -= 2;
            MotorPreTime = MotorCurTime;
        }
    }else if((targetLeftSpeed == 0) && (targetRightSpeed == 0)){
       LEFTSPEED = 0;
       RIGHTSPEED = 0;
    }
    MotorControl(LEFTSPEED, RIGHTSPEED);
}
void UART_SendData() //ros ?? 값을 보내 ?? ?  ?   ?
{
  /* Send data via UART */
  char buffer[50];
  sprintf(buffer,"%d,%3.2f,%d,%2.2f\n",robot,yaw,press,range1); // / 로봇이 작동 중인가? / imu yaw값 / 압력 센서 여부 / UWB 값
  HAL_UART_Transmit(&huart1, (uint8_t*)buffer, strlen(buffer), HAL_MAX_DELAY);
}
////////////////
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart){
   if (huart->Instance == USART2){
      IMU_CallBack();
   }
   else if(huart->Instance == UART4){
      UWB_CallBack();
   }
   else if(huart->Instance == USART1){
//      robot = 1;
//      UART_SendData();
      ROS_CallBack();
   }
}
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */


  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */
  HAL_Delay(100);

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_USART1_UART_Init();
  MX_I2C1_Init();
  MX_UART5_Init();
  MX_TIM2_Init();
  MX_USART2_UART_Init();
  MX_UART4_Init();
  MX_ADC1_Init();
  MX_ADC2_Init();
  MX_CRC_Init();
  MX_RNG_Init();
  /* USER CODE BEGIN 2 */
  millis_init1();
  MOTOR_Init();
  ROS_Init();
  IMU_Init();
  UWB_Init();
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
//     count ++;
//     SRF08_COMMAND1();
//         if(SRF_STATE){
//          SRF08_READ1();
//         }


//     SRF08_READ();

     Distance_State = 0;
     ADC_SENSOR1();
//     ADC_SENSOR2();
        MotorCurTime = millis1();
            if ((robot == 1) && (press  == 1) ) { // 나중에 문제 생기면 전역 변수로 세팅 해주는거로 변
//               press = 1;
//               && (adcValue1 > 100) && (adcValue2 > 100.
                if (CHECK == 1) {
//                   count4 ++;
                    switch (Distance_State) {
                        case 0:
                           ROSLEEFT = map(PL, 0, 3400, 0, 126);
                           ROSRIGHT = map(PR, 0, 3400, 0, 126);
                             if (ROSLEEFT == 0 && ROSRIGHT == 0) {
                                 LEFTSPEED = 0;
                                 RIGHTSPEED = 0;
                                 MotorControl(0, 0);
//                             } else if ((LEFTSPEED == 0 && RIGHTSPEED == 0) || ((LEFTSPEED < 60) && (RIGHTSPEED < 60))) {
//                                 UpdateMotorSpeed(60, 60);
                             } else {
                                 LEFTSPEED = ROSLEEFT;
                                 RIGHTSPEED = ROSRIGHT;
                                 MotorControl(ROSLEEFT, ROSRIGHT);
                             }
                            break;
                        case 1:
                           LEFTSPEED = 0;
                           RIGHTSPEED = 0;
                            MotorControl(0, 0);
                            break;
                        case 2:
                             ROSLEEFT = map(PL, 0, 3400, 0, 126);
                             ROSRIGHT = map(PR, 0, 3400, 0, 126);
                            SlowDownMotor(ROSLEEFT,ROSRIGHT);
                            break;
                    }
                } else if (CHECK == 0) {
//                    count2++;
                    MotorControl(0, 0);
//                   robot = 0;
                }
            } else if ((robot == 0) || (press == 0)) {
//                || (adcValue1 <50) || (adcValue2 < 50)
               LEFTSPEED = 0;
               RIGHTSPEED = 0;
                MotorControl(0, 0);
//                press = 0;
            }
            UART_SendData();

//////////////////////////////////////////////////

//            if (robot == 1 && adcValue1 > 100) {
//                press = 1;
//
//                if (CHECK == 1) {
//                    switch (Distance_State) {
//                        case 0:
//                            ROSLEEFT = map(PL, 0, 3400, 0, 126);
//                            ROSRIGHT = map(PR, 0, 3400, 0, 126);
//                            if (ROSLEEFT == 0 && ROSRIGHT == 0) {
//                                LEFTSPEED = 0;
//                                RIGHTSPEED = 0;
//                                MotorControl(0, 0);
//                            } else {
//                                LEFTSPEED = ROSLEEFT;
//                                RIGHTSPEED = ROSRIGHT;
//                                MotorControl(ROSLEEFT, ROSRIGHT);
//                            }
//                            break;
//                        case 1:
//                            LEFTSPEED = 0;
//                            RIGHTSPEED = 0;
//                            MotorControl(0, 0);
//                            break;
//                        case 2:
//                            ROSLEEFT = map(PL, 0, 3400, 0, 126);
//                            ROSRIGHT = map(PR, 0, 3400, 0, 126);
//                            SlowDownMotor(ROSLEEFT, ROSRIGHT);
//                            break;
//                    }
//                } else {
//                    MotorControl(0, 0);
//                    robot = 0;
//                }
//            }
//            else if (robot == 0 || adcValue1 < 50) {
//                LEFTSPEED = 0;
//                RIGHTSPEED = 0;
//                MotorControl(0, 0);
//                press = 0;
//            }
//

///////////////////////////////////////////////////////////////////////////////////////////////////////
 //before code

//         if(Robot == 1){
//           MotorCurTime = millis1();
//            if(CHECK == 0){
//
//               if(Distance_State == 0){
//                  ROSLEEFT = map(PL,0,3400,0,126);
//                 ROSRIGHT = map(PR,0,3400,0,126);
//                 if((LEFTSPEED < ROSLEEFT) && (RIGHTSPEED < ROSRIGHT)){
//                    if(MotorCurTime - MotorPreTime > MotorDelay){
//                       LEFTSPEED += 1 ;
//                       RIGHTSPEED += 1 ;
//                       MotorPreTime = MotorCurTime ;
//                    }
//                    MotorControl(LEFTSPEED,RIGHTSPEED);
//
//                      }else if((LEFTSPEED == ROSLEEFT) && (RIGHTSPEED == ROSRIGHT)){
//
//                       MotorControl(ROSLEEFT,ROSRIGHT);
//                           }else{
//                             MotorControl(LEFTSPEED,RIGHTSPEED);
//                           }
//
//               }else if (Distance_State == 1){
//                 MotorControl(0,0);
//               }else if(Distance_State == 2){
//                  if((LEFTSPEED < StandardSlowSpeed) && (RIGHTSPEED < StandardSlowSpeed)){
//                 if(MotorCurTime - MotorPreTime > MotorDelay){
//                    LEFTSPEED -= 2 ;
//                    RIGHTSPEED -= 2 ;
//                    MotorPreTime = MotorCurTime ;
//                 }
//                 MotorControl(LEFTSPEED,RIGHTSPEED); // this speed uart3 send ros speed change(?) fuck english
//                  }
//               }
//            }else if(CHECK == 1){
//              MotorControl(0,0);
//            }
//         }else if(Robot == 0){
//           MotorControl(0,0);
//         }
//        MotorCurTime = millis1();
//        if(RobotState == 0 && Distance_State == 0){
//
//        }
//
//     if(RobotState == 0 && Distance_State == 0){
//           MotorControl(100, 100);
//     }
//     else if(Distance_State == 1){
//        MotorControl(0, 0);
//     }
//     else if(RobotState == 0 && Distance_State == 2){
//        MotorControl(50, 50);
//     }
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 4;
  RCC_OscInitStruct.PLL.PLLN = 168;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 7;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  Period elapsed callback in non blocking mode
  * @note   This function is called  when TIM14 interrupt took place, inside
  * HAL_TIM_IRQHandler(). It makes a direct call to HAL_IncTick() to increment
  * a global variable "uwTick" used as application time base.
  * @param  htim : TIM handle
  * @retval None
  */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

#include "roboClaw.h"
#include <stdio.h>

extern SERIAL_HandleTypeDef *hserial_uart5;
extern RoboClaw_HandleTypeDef hroboClaw1;
extern RoboClaw_HandleTypeDef hroboClaw2;
//extern char Jetson_Data[100]={0};
//int data;
uint32_t encoderValue_F1;
uint32_t encoderValue_F2;
uint32_t encoderValue_B1;
uint32_t encoderValue_B2;
uint8_t status_F1 = 0;
uint8_t status_F2 = 0;
uint8_t status_B1 = 0;
uint8_t status_B2 = 0;
void MOTOR_Init()
{
	  hroboClaw1.hserial = hserial_uart5;
	  hroboClaw1.packetserial_address = 0x80;
	  roboClaw_init(&hroboClaw1);
	  ResetEncoders(&hroboClaw1);
//	  hroboClaw2.hserial = hserial_uart5;
//	  hroboClaw2.packetserial_address = 0x81;
//	  roboClaw_init(&hroboClaw2);
//	  ResetEncoders(&hroboClaw2);
//	  DriveM1M2withSpeedandPosition(&hroboClaw1, 0, 0, 0, 0);
//	  DriveM1M2withSpeedandPosition(&hroboClaw2, 0, 0, 0, 0);

}
void MotorControl(int Lspeed, int Rspeed){
	ForwardM2(&hroboClaw1,Rspeed);
	ForwardM1(&hroboClaw1,Lspeed);
//	ForwardM1(&hroboClaw2,Lspeed);
//	ForwardM2(&hroboClaw2,Rspeed);

}
//void MotorCallback(){
//	sscanf(Jetson_Data,"%d",data);
//	B_Forward(data);
//	HAL_UART_Transmit(&huart3, &data, sizeof(data), HAL_MAX_DELAY);
//	HAL_UART_Receive_IT(&huart3, Jetson_Data, sizeof(Jetson_data));
//}

void ResetEnc()
{
		SetEncM1(&hroboClaw1,0);
		SetEncM2(&hroboClaw1,0);
		SetEncM1(&hroboClaw2,0);
		SetEncM2(&hroboClaw2,0);
}

void B_Forward(int value)
{
	DriveM1M2withSpeedandPosition(&hroboClaw1, 1500, 3195 * value, 1500, 3195 * value);
	DriveM1M2withSpeedandPosition(&hroboClaw2, 1500, 3195 * value, 1500, 3195 * value);
}

void B_Backward(int value)
{
	DriveM1M2withSpeedandPosition(&hroboClaw1, 1223, 3195 * value, 1219, 3195 * value);
	DriveM1M2withSpeedandPosition(&hroboClaw2, 1223, 3195 * value, 1219, 3195 * value);
}

void B_Rightward(int value){
	DriveM1M2withSpeedandPosition(&hroboClaw1, 1223, 3195 * value / 2, 1223, 3195 * value);
	DriveM1M2withSpeedandPosition(&hroboClaw2, 1223, 3195 * value / 2, 1223, 3195 * value);
}

void B_Leftward(int value){
	DriveM1M2withSpeedandPosition(&hroboClaw1, 1223, 3195 * value, 1223, 3195 * value / 2);
	DriveM1M2withSpeedandPosition(&hroboClaw2, 1223, 3195 * value, 1223, 3195 * value / 2);
}


void B_Rightward_little(int value){
	DriveM1M2withSpeedandPosition(&hroboClaw1, 200, 320 * value/6, 1200, 320 * value);
	DriveM1M2withSpeedandPosition(&hroboClaw2, 1200, 320 * value, 200, 320 * value/6);
}

void B_Leftward_little(int value){
	DriveM1M2withSpeedandPosition(&hroboClaw1, 1200, 320 * value , 600, 320 * value / 2);
	DriveM1M2withSpeedandPosition(&hroboClaw2, 600, 320 * value / 2, 1200, 320 * value);
}

void B_Rightward_Stay(int value){
	DriveM1M2withSpeedandPosition(&hroboClaw1, 2400, 319 * value, 2400, 319 * value * -1);
	DriveM1M2withSpeedandPosition(&hroboClaw2, 2400, 319 * value, 2400, 319 * value * -1);
}




void B_Rightward_Stay2000(int value){
	DriveM1M2withSpeedandPosition(&hroboClaw1, 2000, 319 * value, 2000, 319 * value * -1);
	DriveM1M2withSpeedandPosition(&hroboClaw2, 2000, 319 * value, 2000, 319 * value * -1);
}

void B_Rightward_Stay1000(int value){
	DriveM1M2withSpeedandPosition(&hroboClaw1, 600, 319 * value*0.6, 1000, 319 * value * -1);
	DriveM1M2withSpeedandPosition(&hroboClaw2, 800, 319 * value*0.8, 400, 319 * value * -1*0.4);
}

void B_Rightward_little1500500(int value){
	DriveM1M2withSpeedandPosition(&hroboClaw1, 500, 320 * value/3, 1500, 320 * value);
	DriveM1M2withSpeedandPosition(&hroboClaw2, 1500, 320 * value, 500, 320 * value/3);
}

void B_Rightward_little2000400(int value){
	DriveM1M2withSpeedandPosition(&hroboClaw1, 200, 320 * value*0.1, 2000, 320 * value);
	DriveM1M2withSpeedandPosition(&hroboClaw2, 2000, 320 * value, 200, 320 * value*0.1);
}

//void B_ReadEncoder1(){
//	encoderValue_F1=ReadEncM1(&hroboClaw1,&status_F1,&encoderValue_F1);
//	printf(encoderValue_F1);
//}
void B_Fordward_test(int value){
	ForwardM1(&hroboClaw1,value);
	ForwardM1(&hroboClaw2,value);
	ForwardM2(&hroboClaw1,value);
	ForwardM2(&hroboClaw2,value);
}






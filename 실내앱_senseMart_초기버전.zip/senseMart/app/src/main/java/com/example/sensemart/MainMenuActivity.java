package com.example.sensemart;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainMenuActivity extends AppCompatActivity {

    private FragmentManager fragmentManager = getSupportFragmentManager();
    private MainMenuSearchFragment fragmentSearch = new MainMenuSearchFragment();
    private MainMenuMapFragment fragmentMap = new MainMenuMapFragment();
    private MainMenuAiFragment fragmentAi = new MainMenuAiFragment();

    boolean chatbot = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_main);

        FragmentTransaction transaction = fragmentManager.beginTransaction();
        transaction.replace(R.id.menu_frame_layout, fragmentSearch).commitAllowingStateLoss();

        BottomNavigationView bottomNavigationView = findViewById(R.id.menu_bottom_navigation);
        bottomNavigationView.setOnNavigationItemSelectedListener(new ItemSelectedListener());

        Intent chatbotIntent = getIntent();
        chatbot = chatbotIntent.getBooleanExtra("chatbot",false);

        if (chatbot) {
            transaction = fragmentManager.beginTransaction();
            transaction.replace(R.id.menu_frame_layout, fragmentAi).commitAllowingStateLoss();

            bottomNavigationView.setSelectedItemId(R.id.menu_ai);
        }
    }

    class ItemSelectedListener implements BottomNavigationView.OnNavigationItemSelectedListener {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {

            FragmentTransaction transaction = fragmentManager.beginTransaction();


            if (item.getItemId() == R.id.menu_search){
                transaction.replace(R.id.menu_frame_layout, fragmentSearch).commitAllowingStateLoss();
            }

            else if (item.getItemId()  == R.id.menu_map){
                transaction.replace(R.id.menu_frame_layout, fragmentMap).commitAllowingStateLoss();
            }

            else if (item.getItemId() == R.id.menu_ai){
                transaction.replace(R.id.menu_frame_layout, fragmentAi).commitAllowingStateLoss();
            }

            return true;
        }
    }
}
package com.example.sensemart;

import static android.content.Context.LOCATION_SERVICE;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.cardview.widget.CardView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ColorDrawable;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationSettingsRequest;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.snackbar.Snackbar;

import java.io.IOException;
import java.util.List;
import java.util.Locale;
import java.util.Objects;

public class MainMenuMapFragment extends Fragment implements OnMapReadyCallback, ActivityCompat.OnRequestPermissionsResultCallback {

    /* Google 지도와 상호작용하기 위한 GoogleMap 인스턴스 */
    private GoogleMap mMap; // 지도의 특성 설정, 마커 추가, 위치 이동 등의 작업 수행

    /* 현재 지도 상에 표시된 마커에 대한 참조 */
    private Marker currentMarker = null; // 마커를 추가할 때마다 변수를 업데이트하여 위치 이동
    private static final String TAG = "googlemap";

    /* 위치 권한과 위치 업데이트 시간 간격 설정 */
    private static final int GPS_ENABLE_REQUEST_CODE = 2001; // GPS 활성화 요청 코드,startActivityForResult()에서 사용
    private static final int UPDATE_INTERVAL_MS = 1000; // 위치 업데이트 간격 설정 변수, 1초 마다 위치 업데이트 수행
    private static final int FASTEST_UPDATE_INTERVAL_MS = 500; // 위치 업데이트의 최소 간격 설정, 0.5초보다 빠른 업데이트는 무시
    private static final int PERMISSION_REQUEST_CODE = 100; // 위치 권한 요청 코드
    boolean needRequest = false; // 위치 권한 요청이 필요한지 나타내는 변수, 필요할 때만 ture로 변경
    String[] REQUIRED_PERMISSION = {Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION};

    /* 사용자 위치 저장 객체*/
    // 두가지 기능을 함께 사용하여 사용자의 위치 실시간 추적 및 Google 지도 표시
    Location mCurrentLocation; // 현재 사용자의 위치 저장, 위치 업데이트가 발생할 때마다 변수 업데이트
    LatLng currentPosition; // 현재 사용자의 위치 저장, 위도와 경도 저장 및 표현

    private FusedLocationProviderClient mFusedLocationClient; // 퓨즈드 위치 제공자 클라이언트 객체, Google Play Service의 Fused Location Provider API 사용
    private LocationRequest locationRequest; // 위치 업데이트 요청을 설정하는 객체, 업데이트 간격, 정확도 등을 설정하여 위치 업데이트 관리
    private Location location; // 현재 위치 정보를 저장하는 객체, 업데이트 이후 현재 위치를 저장하고 이를 기반으로 지도에 표시
    private View mLayout; // snackbar 사용

    boolean moveCamera = true;

    CardView mapCardView;
    TextView cardViewName, cardViewDist, cardViewLocation;
    ImageView cardViewImg;
    Dialog dialog;


    /* fragment의 UI 설정 및 위치 서비스 초기화 */

    @SuppressLint({"ClickableViewAccessibility", "MissingInflatedId"})
    @Nullable // 메서드가 null값을 반환할 수 있음
    @Override // 'Fragment' 클래스의 메서드를 재정의하고 있음
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_main_menu_map, container, false);
        mLayout = view.findViewById(R.id.map); // 인플레이트된 뷰에서 지도를 띄울 뷰의 ID를 변수에 할당

        locationRequest = LocationRequest.create() // 새로운 'LocationRequest' 객체 생성
                .setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY) // 위치 요청의 우선 순위를 높은 정확도로 설정
                .setInterval(UPDATE_INTERVAL_MS) // 위치 업데이트 간격 설정
                .setFastestInterval(FASTEST_UPDATE_INTERVAL_MS); // 위치 업데이트의 최소 간격 설정

        // 위치 서비스의 다양한 설정을 구성할 수 있는 도구 → 위에서 설정한 locationRequest를 적용
        LocationSettingsRequest.Builder builder = new LocationSettingsRequest.Builder(); // 위치 설정 요청을 구성하는 빌더 객체 생성
        builder.addLocationRequest(locationRequest); // 앞에서 생성한 'locationRequest'를 빌더에 추가

        // 현재 Activity의 'FusedLocationProviderClient' 인스턴스를 가져옴
        // 이 인스턴스를 통해 위치 서비스 사용 가능
        mFusedLocationClient = LocationServices.getFusedLocationProviderClient(requireActivity());

        EditText martSearch = view.findViewById(R.id.mart_search); // EditText를 findViewById로 가져옴
        martSearch.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_DOWN) {

                    MainMenuSearchFragment fragmentSearch = new MainMenuSearchFragment();
                    Bundle bundle = new Bundle();
                    bundle.putBoolean("isTouch", true);
                    fragmentSearch.setArguments(bundle);

                    // BottomNavigationView 아이템 선택
                    BottomNavigationView bottomNavigationView = requireActivity().findViewById(R.id.menu_bottom_navigation);
                    bottomNavigationView.setSelectedItemId(R.id.menu_search);

                    // 프래그먼트 트랜잭션
                    if (getActivity() != null) {
                        getActivity().getSupportFragmentManager().beginTransaction()
                                .replace(R.id.menu_frame_layout, fragmentSearch)
                                .commit();
                    }
                }
                return false;
            }
        });


        mapCardView = view.findViewById(R.id.mapCardView);
        cardViewName = view.findViewById(R.id.cardViewName);
        cardViewDist = view.findViewById(R.id.cardViewDist);
        cardViewLocation = view.findViewById(R.id.cardViewLocation);
        cardViewImg = view.findViewById(R.id.cardViewImg);

        dialog = new Dialog(getActivity());
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog);
        Objects.requireNonNull(dialog.getWindow()).setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        ImageButton bakest = (ImageButton) view.findViewById(R.id.basket);
        bakest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), Bakest.class);
//                intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                startActivity(intent);
            }
        });

        // 'SupportMapFragment'는 Google Maps SDK를 사용하여 지도를 표시하는 fragment
        SupportMapFragment mapFragment = (SupportMapFragment) getChildFragmentManager().findFragmentById(R.id.map);
        if (mapFragment != null) { // null이 아닌 경우, 비동기적으로 지도를 로드하도록 요청
            // 'this'는 'OnMapReadyCallback' 인터페이스를 구현하는 현재 fragment
            mapFragment.getMapAsync(this);
        }
        return view; // 인플레이트된 뷰 반환

    }

    /* Google Map이 준비되면 호출되는 callback 메서드 */
    @RequiresApi(api = Build.VERSION_CODES.M) // Android M (API 23) 이상만 호출될 수 있음
    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {

        mMap = googleMap; // 준비된 'GoogleMap' 객체를 변수에 할당

        setDefaultLocation(); // 지도의 기본 위치를 설정하는 메서드 호출

        // 현재 Activity에 대해 지정된 권한이 부여되었는지 확인
        int hasFineLocationPermission = ContextCompat.checkSelfPermission(requireActivity(), Manifest.permission.ACCESS_FINE_LOCATION); // 고정밀 위치 권한
        int hasCoarseLocationPermission = ContextCompat.checkSelfPermission(requireActivity(), Manifest.permission.ACCESS_COARSE_LOCATION); // 대략적 위치 권한

        // 위치 권한이 모두 부여된 경우 'startLocationUpdates()' 메서드를 호출하여 위치 업데이트 시작
        if (hasFineLocationPermission == PackageManager.PERMISSION_GRANTED && hasCoarseLocationPermission == PackageManager.PERMISSION_GRANTED) {
            startLocationUpdates();
        } else { // 권한이 부여되지 않은 경우 권한 요청
            if (ActivityCompat.shouldShowRequestPermissionRationale(requireActivity(), REQUIRED_PERMISSION[0])) { // 사용자가 이전에 권한 요청을 거부한적 있는지 확인
                Snackbar.make(mLayout, "이 앱을 실행하려면 위치 접근 권한이 필요합니다.", Snackbar.LENGTH_INDEFINITE)
                        .setAction("확인", new View.OnClickListener() { // Snackbar의 확인을 클릭하면 메서드를 호출하여 권한 요청
                            @Override
                            public void onClick(View view) {
                                ActivityCompat.requestPermissions(requireActivity(), REQUIRED_PERMISSION, PERMISSION_REQUEST_CODE);
                            }
                        }).show();
            } else { // 사용자가 이전에 권한 요청을 거부하지 않았다면 바로 메서드를 호출하여 권한 요청
                ActivityCompat.requestPermissions(requireActivity(), REQUIRED_PERMISSION, PERMISSION_REQUEST_CODE);
            }
        }

        mMap.getUiSettings().setMyLocationButtonEnabled(true); // 지도에 '내 위치' 버튼 활성화
        mMap.setOnMapClickListener(new GoogleMap.OnMapClickListener() { // 지도를 클릭할 때 호출되는 리스너
            @Override
            public void onMapClick(@NonNull LatLng latLng) {
                Log.d(TAG, "onMapClick: ");
            }
        });

        addMartMaker();
    }

    private void addMartMaker() {

        /* 트레이더스홀세일클럽 월계점 */
        LatLng martTradusLatLng = new LatLng(37.627809,127.061394);
        String martTradusTitle = "트레이더스홀세일클럽 월계점";
        String martTradusSnippet = getCurrentAddress(martTradusLatLng);

        MarkerOptions martTradusMaker = new MarkerOptions();
        martTradusMaker.position(martTradusLatLng);

        // drawable 리소스를 'BitmapDrawable' 타입으로 캐스팅
        // 'BitmapDrawable'은 drawable 리소스를 'Bitmap' 객체로 변환
        BitmapDrawable drawTradus = (BitmapDrawable) getResources().getDrawable(R.drawable.martmarker);
        Bitmap Drawtrauds = drawTradus.getBitmap(); // 'BitmapDrawable' 객체에서 'Bitmap' 객체 추출
        Bitmap tradusIcon = Bitmap.createScaledBitmap(Drawtrauds,130,130,false); // 객체의 크기와 필터링 적용 유무 설정
        martTradusMaker.icon(BitmapDescriptorFactory.fromBitmap(tradusIcon));

        mMap.addMarker(martTradusMaker);

        /* 롯데슈퍼 중계점 */
        LatLng martLotteLatLng = new LatLng(37.634968,127.065603);
        String martLotteTitle = "롯데슈퍼 중계점";
        String martLotteSnippet = getCurrentAddress(martLotteLatLng);

        MarkerOptions martLotteMaker = new MarkerOptions();
        martLotteMaker.position(martLotteLatLng);

        BitmapDrawable drawLotte = (BitmapDrawable) getResources().getDrawable(R.drawable.martmarker);
        Bitmap Drawlotte = drawLotte.getBitmap();
        Bitmap lotteIcon = Bitmap.createScaledBitmap(Drawlotte,130,130,false);
        martLotteMaker.icon(BitmapDescriptorFactory.fromBitmap(lotteIcon));

        mMap.addMarker(martLotteMaker);

        /* 하모니마트 월계점 */
        LatLng martHarmonyLatLng = new LatLng(37.622478,127.052981);
        String martHarmonyTitle = "하모니마트 월계점";
        String martHarmonySnippet = getCurrentAddress(martHarmonyLatLng);

        MarkerOptions martHarmonyMaker = new MarkerOptions();
        martHarmonyMaker.position(martHarmonyLatLng);

        BitmapDrawable drawHarmony = (BitmapDrawable) getResources().getDrawable(R.drawable.martmarker);
        Bitmap Drawharmony = drawHarmony.getBitmap();
        Bitmap harmonyIcon = Bitmap.createScaledBitmap(Drawharmony,130,130,false);
        martHarmonyMaker.icon(BitmapDescriptorFactory.fromBitmap(harmonyIcon));

        mMap.addMarker(martHarmonyMaker);

        /* 청구마트 */
        LatLng martChungGuLatLng = new LatLng(37.636421,127.061316);
        String martChungGuTitle = "청구마트";
        String martChungGuSnippet = getCurrentAddress(martChungGuLatLng);

        MarkerOptions martChungGuMaker = new MarkerOptions();
        martChungGuMaker.position(martChungGuLatLng);

        BitmapDrawable drawChungGu = (BitmapDrawable) getResources().getDrawable(R.drawable.martmarker);
        Bitmap Drawchungu = drawChungGu.getBitmap();
        Bitmap chungguIcon = Bitmap.createScaledBitmap(Drawchungu,130,130,false);
        martChungGuMaker.icon(BitmapDescriptorFactory.fromBitmap(chungguIcon));

        mMap.addMarker(martChungGuMaker);

        /* J마트 */
        LatLng martJayLatLng = new LatLng(37.645965,127.064134);
        String martJayTitle = "J마트";
        String martJaySnippet = getCurrentAddress(martJayLatLng);

        MarkerOptions martJayMaker = new MarkerOptions();
        martJayMaker.position(martJayLatLng);

        BitmapDrawable drawJay = (BitmapDrawable) getResources().getDrawable(R.drawable.martmarker);
        Bitmap Drawjay = drawJay.getBitmap();
        Bitmap jayIcon = Bitmap.createScaledBitmap(Drawjay,130,130,false);
        martJayMaker.icon(BitmapDescriptorFactory.fromBitmap(jayIcon));

        mMap.addMarker(martJayMaker);

        /* 이마트 월계점 */
        LatLng martEmartLatLng = new LatLng(37.626433,127.061917);
        String martEmartTitle = "이마트 월계점";
        String martEmartSnippet = getCurrentAddress(martEmartLatLng);

        MarkerOptions martEmartMaker = new MarkerOptions();
        martEmartMaker.position(martEmartLatLng);

        BitmapDrawable drawEmart = (BitmapDrawable) getResources().getDrawable(R.drawable.martmarker);
        Bitmap Drawemart = drawEmart.getBitmap();
        Bitmap emartIcon = Bitmap.createScaledBitmap(Drawemart,130,130,false);
        martEmartMaker.icon(BitmapDescriptorFactory.fromBitmap(emartIcon));

        mMap.addMarker(martEmartMaker);

        /* 클릭 시 카메라 이동 */

        mMap.setOnMarkerClickListener(new GoogleMap.OnMarkerClickListener() {
            @Override
            public boolean onMarkerClick(@NonNull Marker marker) {
                moveCamera = false;
                if (!moveCamera) {
                    // 마커의 위치로 카메라 이동
                    LatLng markerPosition = marker.getPosition();
                    mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(markerPosition, 15));

                    // 현재 클릭한 마커가 이마트 월계점의 위도 경도이면 카드뷰 보임
                    if (markerPosition.equals(martEmartLatLng)){
                        cardViewName.setText(martEmartTitle);
                        cardViewDist.setText(getDistance(location.getLatitude(),location.getLongitude(),martEmartLatLng.latitude,martEmartLatLng.longitude));
                        cardViewLocation.setText(martEmartSnippet);
                        cardViewImg.setImageResource(R.drawable.mart_image);
                        mapCardView.setVisibility(View.VISIBLE);

                    } else if (markerPosition.equals(martTradusLatLng)) {
                        cardViewName.setText(martTradusTitle);
                        cardViewLocation.setText(martTradusSnippet);
                        cardViewDist.setText(getDistance(location.getLatitude(),location.getLongitude(),martTradusLatLng.latitude,martTradusLatLng.longitude));
                        cardViewImg.setImageResource(R.drawable.non_market_img);
                        mapCardView.setVisibility(View.VISIBLE);

                    } else if (markerPosition.equals(martLotteLatLng)){
                        cardViewName.setText(martLotteTitle);
                        cardViewLocation.setText(martLotteSnippet);
                        cardViewDist.setText(getDistance(location.getLatitude(),location.getLongitude(),martLotteLatLng.latitude,martLotteLatLng.longitude));
                        cardViewImg.setImageResource(R.drawable.non_market_img);
                        mapCardView.setVisibility(View.VISIBLE);

                    } else if (markerPosition.equals(martHarmonyLatLng)) {
                        cardViewName.setText(martHarmonyTitle);
                        cardViewLocation.setText(martHarmonySnippet);
                        cardViewDist.setText(getDistance(location.getLatitude(),location.getLongitude(),martHarmonyLatLng.latitude,martHarmonyLatLng.longitude));
                        cardViewImg.setImageResource(R.drawable.non_market_img);
                        mapCardView.setVisibility(View.VISIBLE);
                    } else if (markerPosition.equals(martChungGuLatLng)) {
                        cardViewName.setText(martChungGuTitle);
                        cardViewLocation.setText(martChungGuSnippet);
                        cardViewDist.setText(getDistance(location.getLatitude(),location.getLongitude(),martChungGuLatLng.latitude,martChungGuLatLng.longitude));
                        cardViewImg.setImageResource(R.drawable.non_market_img);
                        mapCardView.setVisibility(View.VISIBLE);

                    } else if (markerPosition.equals(martJayLatLng)) {
                        cardViewName.setText(martJayTitle);
                        cardViewLocation.setText(martJaySnippet);
                        cardViewDist.setText(getDistance(location.getLatitude(),location.getLongitude(),martJayLatLng.latitude,martJayLatLng.longitude));
                        cardViewImg.setImageResource(R.drawable.non_market_img);
                        mapCardView.setVisibility(View.VISIBLE);

                    } else {
                        mapCardView.setVisibility(View.GONE);
                    }

                    mapCardView.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            if(markerPosition.equals(martEmartLatLng)) {
                                Intent intent = new Intent(getActivity(), MartCategory.class);
                                intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                                startActivity(intent);
                            }
                            else{
                                customToastView("마트에 대한 정보가 없습니다.");
                            }
                        }

                    });
                }
                return false;
            }
        });
        moveCamera = true;
    }


    private String getDistance(double meLatitude, double meLongitude, double martLatitude, double martLongitude){
        Location locationMe = new Location("pointMart");

        locationMe.setLatitude(meLatitude);
        locationMe.setLongitude(meLongitude);

        Location locationMart = new Location("pointMart");

        locationMart.setLatitude(martLatitude);
        locationMart.setLongitude(martLongitude);

        int distance = (int) locationMe.distanceTo(locationMart);

        String Distance = Double.toString(distance);

        return Distance;
    }

    private void customToastView(String s) {
        LayoutInflater inflater = getLayoutInflater();
        View layout = inflater.inflate(R.layout.toast_custom, getActivity().findViewById(R.id.toast_layout_root));
        TextView textView = layout.findViewById(R.id.textboard);
        textView.setText(s);

        Toast toast = Toast.makeText(getActivity(),s,Toast.LENGTH_SHORT);
        toast.setView(layout);
        toast.show();
    }

    /* 위치 업데이트를 받을 때 호출되는 콜백 함수 */
    LocationCallback locationCallback = new LocationCallback() { // 'LocationCallback'은 위치 업데이트를 처리하기 위한 콜백 객체
        @Override
        public void onLocationResult(@NonNull LocationResult locationResult) {
            super.onLocationResult(locationResult); // 'locationResult' 는 위치 업데이트 결과를 포함하는 객체

            List<Location> locationList = locationResult.getLocations(); // 'locationResult'에서 위치 리스트를 가져옴

            if (locationList.size() > 0) { // 위치 리스트가 비어있는지 확인
                location = locationList.get(locationList.size() - 1);  // 가장 최신 위치를 가져와 'location' 변수에 할당

                currentPosition = new LatLng(location.getLatitude(), location.getLongitude()); // 위도와 경도를 가져와 'LatLng' 객체를 생성하고 'currentPosition' 변수에 할당

                String markerTitle = getCurrentAddress(currentPosition); // 현재의 위치의 주소를 가져와 변수에 할당 (서울 노원구 어쩌구~)
                String markerSnippet = "위도: " + location.getLatitude() + " 경도: " + location.getLongitude(); // 위도와 경도를 포함하는 설명 문자열을 생성하여 변수에 할당

                setCurrentLocation(location, markerTitle, markerSnippet); // 현재 위치를 지도에 마커로 표시

                mCurrentLocation = location; // 현재 위치를 저장하는 변수 'mCurrentLocation'에 최신 위치 할당
            }
        }
    };

    /* 위도와 경도를 통해 현재 위치의 주소를 알아내는 메서드 */
    private String getCurrentAddress(LatLng currentPosition) {

        // 'Geocoder'은 GPS 좌표를 주소로 변환하거나, 주소를 GPS 좌표로 변환하는 데 사용되는 class
        // 현재 fragment가 연결된 Activity를 반환하며, 기본 Locale을 설정하여 주소를 변환
        Geocoder geocoder = new Geocoder(requireActivity(), Locale.getDefault());

        List<Address> addresses; // 변환할 주소 목록을 저장할 리스트

        try { // 주어진 위도와 경도를 사용하여 주소를 얻음, '1'은 최대 결과 수를 1로 설정하여 하나의 주소만 반환받음
            addresses = geocoder.getFromLocation(currentPosition.latitude, currentPosition.longitude, 1);
        } catch (IOException ioException) { // 네트워크 문제 등으로 인해 'Geocoder' 서비스에 접근할 수 있는 경우 발생
            Toast.makeText(requireActivity(), "지오코더 서비스 사용불가", Toast.LENGTH_LONG).show();
            return "지오코더 서비스 사용 불가";
        } catch (IllegalArgumentException illegalArgumentException) { // 잘못된 위도, 경도 값이 주어진 경우 발생
            Toast.makeText(requireActivity(), "잘못된 GPS 좌표", Toast.LENGTH_LONG).show();
            return "잘못된 GPS 좌표";
        }

        if (addresses == null || addresses.isEmpty()) { // 'adresses'가 null이거나 비어있는 경우 발생
            Toast.makeText(requireActivity(), "주소 미발견", Toast.LENGTH_LONG).show();
            return "주소 미발견";
        } else { // 'addresses' 리스트에 주소가 포함되어 있는 경우, 첫 번째 주소 객체를 'address' 변수에 할당
            Address address = addresses.get(0);
            return address.getAddressLine(0); // 주소 객체의 첫 번째 주소 라인은 반환
        }
    }


    /* 위치에 대한 마커 설정 및 카메라 이동 */
    private void setCurrentLocation(Location location, String markerTitle, String markerSnippet) {
        if (currentMarker != null) { // 이전에 설정된 마커가 존재하는 경우 삭제
            currentMarker.remove();
        }

        // 'location' 객체에서 위도와 경도를 가져와 'LatLng' 객체 생성
        LatLng currentLatLng = new LatLng(location.getLatitude(), location.getLongitude());

        /* 마커의 속성 설정*/
        MarkerOptions markerOptions = new MarkerOptions();
        markerOptions.position(currentLatLng); // 마커의 위치 설정
        markerOptions.draggable(true); // 마커를 드래그할 수 있도록 설정

        BitmapDrawable drawMe = (BitmapDrawable) getResources().getDrawable(R.drawable.memarker2);
        Bitmap Drawme = drawMe.getBitmap();
        Bitmap meIcon = Bitmap.createScaledBitmap(Drawme,130,130,false);
        markerOptions.icon(BitmapDescriptorFactory.fromBitmap(meIcon));

        currentMarker = mMap.addMarker(markerOptions); // 설정된 옵션으로 지도의 해당 위치에 마커 추가

        if (moveCamera) {
            CameraUpdate cameraUpdate = CameraUpdateFactory.newLatLng(currentLatLng); // 지정된 위치로 이동하기 위한 업데이트 객체 생성
            mMap.moveCamera(cameraUpdate); // 해당 위치로 이동
        }
    }

    /* 위치 서비스가 활성화, 위치 권환을 확인하고 권한이 있는 경우 위치 업데이트 요청 및 지도 위치 기능 활성화 */
    @RequiresApi(api = Build.VERSION_CODES.M)
    private void startLocationUpdates() {
        if (!checkLocationServicesStatus()) {  // 위치 서비스 활성화 확인
            showDialogForLocationServiceSetting(); // 활성화가 되지 않은 경우, 위치 서비스 설정을 요청하는 Dialog 표시
        } else { // 권한이 부여되었는지 확인
            int hasFineLocationPermission = ContextCompat.checkSelfPermission(requireActivity(), Manifest.permission.ACCESS_FINE_LOCATION);
            int hasCoarseLocationPermission = ContextCompat.checkSelfPermission(requireActivity(), Manifest.permission.ACCESS_COARSE_LOCATION);

            // 권한이 부여되지 않았을 경우 Log 메시지 출력
            if (hasFineLocationPermission != PackageManager.PERMISSION_GRANTED || hasCoarseLocationPermission != PackageManager.PERMISSION_GRANTED) {
                Log.d(TAG, "startLocationUpdates: 퍼미션 없음");
                return;
            }

            /* 위치 업데이트 요청*/
            // 'locationRequest' 는 위치 요청 설정을 나타내는 객체
            // 'locationCallback' 위치 업데이트를 받을 때 호출되는 콜백 객체
            // 'Looper.myLooper()' 현재 스레드의 루퍼 사용
            mFusedLocationClient.requestLocationUpdates(locationRequest, locationCallback, Looper.myLooper());
            if (checkPermission()) { // 권한이 있는 경우
                mMap.setMyLocationEnabled(true); // 지도의 "내 위치" 기능 활성화
            }
        }
    }

    /* 앱의 화면이 사용자에게 보여지기 시작할 때 호출 */
    @Override
    public void onStart() {
        super.onStart();

        if (checkPermission()) {
            mFusedLocationClient.requestLocationUpdates(locationRequest, locationCallback, null);
            if (mMap != null) {
                mMap.setMyLocationEnabled(true);
            }
        }
    }

    /* 앱의 화면이 사용자에게 보여지지 않을 때 호출 */
    @Override
    public void onStop() {
        super.onStop();

        if (mFusedLocationClient != null) { // null이 아닌 경우 실행
            // 이전에 요청한 위치 업데이트 제거
            mFusedLocationClient.removeLocationUpdates(locationCallback);
        }
    }

    /* 위치 권환 확인 코드 */
    private boolean checkPermission() {
        int hasFineLocationPermission = ContextCompat.checkSelfPermission(requireActivity(), Manifest.permission.ACCESS_FINE_LOCATION);
        int hasCoarseLocationPermission = ContextCompat.checkSelfPermission(requireActivity(), Manifest.permission.ACCESS_COARSE_LOCATION);

        return hasFineLocationPermission == PackageManager.PERMISSION_GRANTED && hasCoarseLocationPermission == PackageManager.PERMISSION_GRANTED;
    }

    /* 위치 서비스가 비활성화되어 있을 때 사용자에게 위치 서비스 활성화 요청 다이얼로그 */
    private void showDialogForLocationServiceSetting() {
        AlertDialog.Builder builder = new AlertDialog.Builder(requireActivity()); // 현재 Activity context를 사용하여 객체 생성
        builder.setTitle("위치 서비스 비활성화");
        builder.setMessage("앱을 사용하기 위해서는 위치 서비스가 필요합니다. 위치설정을 수정하시겠습니까?");
        builder.setCancelable(true); // 다이얼로그가 취소 가능하도록 설정 → 외부를 터치하면 다이얼로그가 닫힘
        builder.setPositiveButton("설정", new DialogInterface.OnClickListener() { // '설정' 버튼이 클릭되었을 경우
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                Intent callGPSSettingIntent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS); // 위치 설정 화면을 여는 인텐트 생성
                startActivityForResult(callGPSSettingIntent, GPS_ENABLE_REQUEST_CODE); // 생성된 인텐트를 사용하여 위치 설정 화면 열기
            }
        });
        builder.setNegativeButton("취소", new DialogInterface.OnClickListener() { // '취소' 버튼이 클릭되었을 경우
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.cancel(); // 다이얼로그 취소 및 닫기
            }
        });
        builder.create().show(); // 다이얼로그 설정된 속성을 바탕으로 생성 및 표시
    }

    /* 위치 서비스가 활성화되어 있는지 확인 */
    @RequiresApi(api = Build.VERSION_CODES.M)
    private boolean checkLocationServicesStatus() { // 위치 서비스의 활성화 상태를 확인하고 return을 통해 값 반환
        // 현재 fragment가 연결된 Activity에서 위치 서비스를 가져온 위치 서비스 객체를 'locationManager' 변수에 할당
        LocationManager locationManager = (LocationManager) requireActivity().getSystemService(LOCATION_SERVICE);

        // GPS 위치 제공자가 활성화되어 있는지 확인 → 활성화된 경우 'true' 반환
        return locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER) || locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
    }

    private void setDefaultLocation() {
        LatLng DEFAULT_LOCATION = new LatLng(37.62, 127.05);
        String markerTitle = "위치 정보 가져올 수 없음";
        String markerSnippet = "위치 퍼미션과 GPS 활성 여부를 확인하세요";

        if (currentMarker != null) {
            currentMarker.remove();
        }

        MarkerOptions markerOptions = new MarkerOptions();
        markerOptions.position(DEFAULT_LOCATION);
        markerOptions.title(markerTitle);
        markerOptions.snippet(markerSnippet);
        markerOptions.draggable(true);
        currentMarker = mMap.addMarker(markerOptions);

        CameraUpdate cameraUpdate = CameraUpdateFactory.newLatLngZoom(DEFAULT_LOCATION, 15);
        mMap.moveCamera(cameraUpdate);
    }
}

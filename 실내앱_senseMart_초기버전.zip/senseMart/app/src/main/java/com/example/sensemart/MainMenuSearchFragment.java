package com.example.sensemart;

import static android.content.Context.LOCATION_SERVICE;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.app.Dialog;
import android.view.Window;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.model.LatLng;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Objects;

public class MainMenuSearchFragment extends Fragment {

    private ListView martList;
    private com.example.sensemart.MainMenuSearchFragment.MartAdapter adapter;
    private String[] martName, martLocation;
    private int[] martDist;
    private int[] martImage;
    Dialog dialog;
    private ArrayList<Mart> martArrayList;
    private ArrayList<Mart> filteredList;
    boolean isTouch = false;
    TextView searchResultNumber;
    private LocationManager locationManager;

    private double martCoordinates[][] = {
            {37.627809, 127.061394}, // 트레이더스홀세일클럽 월계점
            {37.634968, 127.065603}, // 롯데슈퍼 중계점
            {37.622478, 127.052981}, // 하모니마트 월계점
            {37.636421, 127.061316}, // 청구마트
            {37.645965, 127.064134}, // J마트
            {37.626433, 127.061917}  // 이마트 월계점
    };

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        ViewGroup rootView = (ViewGroup) inflater.inflate(R.layout.fragment_main_menu_search, container, false);

        searchResultNumber = rootView.findViewById(R.id.search_result_number);
        martName = getResources().getStringArray(R.array.martName);
        martDist = getResources().getIntArray(R.array.martDist);
        martLocation = getResources().getStringArray(R.array.martLocation);
        martImage = new int[]{
                R.drawable.non_market_img,
                R.drawable.non_market_img,
                R.drawable.non_market_img,
                R.drawable.non_market_img,
                R.drawable.non_market_img,
                R.drawable.mart_image
        };

        // 위치 정보 관리 객체
        locationManager = (LocationManager) requireActivity().getSystemService(LOCATION_SERVICE);

        // 위치 권한 확인
        if (Build.VERSION.SDK_INT >= 23 &&
                ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(requireActivity(), new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 0);
        } else {
            getLocationUpdates();
        }

        dialog = new Dialog(getActivity());
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog);
        Objects.requireNonNull(dialog.getWindow()).setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        martList = rootView.findViewById(R.id.mart_list);
        martList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Mart selectedMart = filteredList.get(position);
                if (selectedMart.getMartName().equals("이마트 월계점")) {
                    Intent intent = new Intent(getActivity(), MartCategory.class);
                    intent.putExtra("MartName", selectedMart.getMartName());
                    startActivity(intent);
                } else {
                    customToastView("마트에 대한 정보가 없습니다.");
                }
            }
        });

        ImageButton basket_btn = rootView.findViewById(R.id.basket);
        basket_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), Bakest.class);
                startActivity(intent);
            }
        });

        martArrayList = new ArrayList<>();
        for (int i = 0; i < martName.length; i++) {
            martArrayList.add(new Mart(martName[i], martDist[i], martLocation[i], martImage[i]));
        }

        // martArrayList를 martDist로 정렬
        Collections.sort(martArrayList);

        filteredList = new ArrayList<>(martArrayList);
        adapter = new com.example.sensemart.MainMenuSearchFragment.MartAdapter(getActivity(), filteredList);
        martList.setAdapter(adapter);

        EditText martSearch = rootView.findViewById(R.id.mart_search);
        Bundle arguments = getArguments();
        if (arguments != null) {
            isTouch = arguments.getBoolean("isTouch", false);
        }
        if (isTouch) {
            martSearch.requestFocus();
            martSearch.postDelayed(() -> {
                InputMethodManager imm = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.showSoftInput(martSearch, InputMethodManager.SHOW_IMPLICIT);
            }, 200);
        }

        martSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                filter(s.toString());
            }
            @Override
            public void afterTextChanged(Editable s) {
            }
        });
        return rootView;
    }

    private void filter(String query) {
        filteredList.clear();
        if (query.isEmpty()) {
            filteredList.addAll(martArrayList);
        } else {
            for (Mart mart : martArrayList) {
                if (mart.getMartName().toLowerCase().contains(query.toLowerCase())) {
                    filteredList.add(mart);
                }
            }
        }
        searchResultNumber.setText("검색결과 ("+ filteredList.size() + ")");
        adapter.notifyDataSetChanged();
    }

    private void customToastView(String s) {
        LayoutInflater inflater = getLayoutInflater();
        View layout = inflater.inflate(R.layout.toast_custom, getActivity().findViewById(R.id.toast_layout_root));
        TextView textView = layout.findViewById(R.id.textboard);
        textView.setText(s);

        Toast toast = new Toast(getActivity());
        toast.setView(layout);
        toast.show();
    }

    private void getLocationUpdates() {
        try {
            Location location = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if (location != null) {
                updateLocationInfo(location);
            }
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000, 1, locationListener);
            locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 1000, 1, locationListener);
        } catch (SecurityException e) {
            e.printStackTrace();
        }
    }

    private void updateLocationInfo(Location location) {
        double longitude = location.getLongitude();
        double latitude = location.getLatitude();

        if (longitude > 0 && latitude > 0) {
            for (int i = 0; i < 6; i++) {
                System.out.println(i + ": " + martCoordinates[i][0] + "," + martCoordinates[i][1] + "\n");
                martDist[i] = getDistance(latitude, longitude, martCoordinates[i][0], martCoordinates[i][1]);
                System.out.println("martDist: " + martDist[i] + "\n");
            }

            System.out.println(
                    "Latitude: " + latitude + "\n" + "Longitude: " + longitude);
        }
    }

    private final LocationListener locationListener = new LocationListener() {
        @Override
        public void onLocationChanged(@NonNull Location location) {
            updateLocationInfo(location);
        }
        @Override
        public void onStatusChanged(String provider, int status, Bundle extras) {}
        @Override
        public void onProviderEnabled(@NonNull String provider) {}
        @Override
        public void onProviderDisabled(@NonNull String provider) {}
    };

    private int getDistance(double meLatitude, double meLongitude, double martLatitude, double martLongitude){
        Location locationMe = new Location("pointMart");

        locationMe.setLatitude(meLatitude);
        locationMe.setLongitude(meLongitude);

        Location locationMart = new Location("pointMart");

        locationMart.setLatitude(martLatitude);
        locationMart.setLongitude(martLongitude);

        int distance = (int) locationMe.distanceTo(locationMart);

        return distance;
    }

    class MartAdapter extends ArrayAdapter<Mart> {
        Context context;
        ArrayList<Mart> martList;

        MartAdapter(Context c, ArrayList<Mart> martList) {
            super(c, R.layout.mart_frame, martList);
            this.context = c;
            this.martList = martList;
        }

        @NonNull
        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            LayoutInflater inflater = LayoutInflater.from(context);
            View martInfo = inflater.inflate(R.layout.mart_frame, parent, false);

            ImageView martImage = martInfo.findViewById(R.id.mart_img);
            TextView martName = martInfo.findViewById(R.id.mart_name);
            TextView martDist = martInfo.findViewById(R.id.mart_dist);
            TextView martLocation = martInfo.findViewById(R.id.mart_location);

            Mart currentMart = martList.get(position);

            martImage.setImageResource(currentMart.getImageResource());
            martDist.setText(String.valueOf(currentMart.getMartDist()));
            martName.setText(currentMart.getMartName());
            martLocation.setText(currentMart.getMartLocation());

            return martInfo;
        }
    }
}
package com.example.sensemart;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;
import android.text.TextWatcher;
import android.text.Editable;


import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import android.app.Dialog;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;


public class MartCategory extends AppCompatActivity {
    private ListView categoryList;
    boolean isTouch = false;
    private String selectedCategoryType = "processed_food";
    FloatingActionButton floatingButton;
    boolean chatbot = false;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.category_layout);

        categoryList = findViewById(R.id.category_list); // 리스트뷰 불러오기

        String[] processedFoodCategory = getResources().getStringArray(R.array.processedFoodCategory);
        String[] freshFoodCategory = getResources().getStringArray(R.array.freshFoodCategory);
        String[] cosmeticCategory = getResources().getStringArray(R.array.cosmeticCategory);
        String[] sportCategory = getResources().getStringArray(R.array.sportCategory);
        String[] underwearCategory = getResources().getStringArray(R.array.underwearCategory);
        String[] lifeCategory = getResources().getStringArray(R.array.lifeCategory);

        Button processed_food_btn = findViewById(R.id.processed_food_btn);
        processed_food_btn.setBackgroundResource(R.drawable.draw4);

        Button fresh_food_btn = findViewById(R.id.fresh_food_btn);
        Button cosmetic_btn = findViewById(R.id.cosmetic_btn);
        Button sport_btn = findViewById(R.id.sport_btn);
        Button underwear_btn = findViewById(R.id.underwear_btn);
        Button life_btn = findViewById(R.id.life_btn);

        // categoryName 배열을 사용하여 어댑터를 초기 설정
        CategoryAdapter adapter = new CategoryAdapter(this, processedFoodCategory);
        categoryList.setAdapter(adapter);

        /* 카테고리 버튼과 카테고리 Array 매핑 */
        Map<Button, String[]> buttonCategoryMap = new HashMap<>();
        buttonCategoryMap.put(processed_food_btn, processedFoodCategory); // 각 버튼을 key, 해당하는 카테고리 배열값을 'buttonCategoryMap'에 할당
        buttonCategoryMap.put(fresh_food_btn, freshFoodCategory);
        buttonCategoryMap.put(cosmetic_btn, cosmeticCategory);
        buttonCategoryMap.put(sport_btn, sportCategory);
        buttonCategoryMap.put(underwear_btn, underwearCategory);
        buttonCategoryMap.put(life_btn, lifeCategory);

        /* 뒤로가기 버튼 */
        ImageButton back_btn = findViewById(R.id.back_btn);
        back_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        /* 장바구니 가기 버튼 */
        ImageButton bakest = (ImageButton) findViewById(R.id.basket);
        bakest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),Bakest.class);
                startActivity(intent);
            }
        });


        /* 카테고리 클릭 이벤트 */
        categoryList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                // 클릭한 항목의 텍스트 가져오기
                String selectedCategory = parent.getItemAtPosition(position).toString();

                // Intent 생성 및 데이터 추가
                Intent intent = new Intent(MartCategory.this, ProductList.class);
                intent.putExtra("category", selectedCategory);
                intent.putExtra("bigcategory",selectedCategoryType);

                startActivity(intent);
            }
        });


        /* 버튼 클릭 시 이벤트 */
        View.OnClickListener categoryButtonListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Button clickedButton = (Button) v; // 'v'는 클릭된 뷰 객체

                // 클릭된 버튼에 따라 카테고리 목록 업데이트
                // 클릭된 버튼에 대응하는 카테고리 데이터를 가져와 어댑터를 새로 생성하고 'categoryList'에 설정
                String[] categoryData = buttonCategoryMap.get(clickedButton);
                CategoryAdapter adapter = new CategoryAdapter(MartCategory.this, categoryData);
                categoryList.setAdapter(adapter);

                // 모든 버튼의 배경 초기화
                for (Button button : buttonCategoryMap.keySet()) {
                    button.setBackgroundResource(R.drawable.button_draw1);
                }
                clickedButton.setBackgroundResource(R.drawable.draw4); // 클릭된 버튼만 배경 변경

                // 선택된 카테고리 유형 저장 ("processed_food", "fresh_food" 등)
                if (clickedButton == processed_food_btn) {
                    selectedCategoryType = "processed_food";
                } else if (clickedButton == fresh_food_btn){
                    selectedCategoryType = "fresh_food";
                } else if (clickedButton == cosmetic_btn) {
                    selectedCategoryType = "cosmetic";
                } else if (clickedButton == sport_btn) {
                    selectedCategoryType = "sports";
                } else if (clickedButton == underwear_btn) {
                    selectedCategoryType = "underwear";
                } else if (clickedButton == life_btn) {
                    selectedCategoryType = "life";
                }
            }
        };

        // 모든 버튼에 대해 'categoryButtonListener을 설정하여 클릭 이벤트 처리
        for (Button button : buttonCategoryMap.keySet()) {
            button.setOnClickListener(categoryButtonListener);
        }

        /* 상품 검색 실행했을 때 ProductList class로 전환 */
        EditText productSearch = findViewById(R.id.mart_search);
        productSearch.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (event.getAction()==MotionEvent.ACTION_DOWN){
                    isTouch = true;
                    Intent intent = new Intent(MartCategory.this, ProductList.class);
                    intent.putExtra("isTouch", isTouch);
                    startActivity(intent);
                }
                return false;
            }
        });

        floatingButton = findViewById(R.id.map_btn);
        floatingButton.setOnClickListener(v -> {
            Intent intent = new Intent(MartCategory.this, MainMenuActivity.class);
            chatbot = true;
            intent.putExtra("chatbot", chatbot);
            startActivity(intent);
        });
    }

    class CategoryAdapter extends ArrayAdapter<String> {
        Context context;
        String[] rCategoryName;

        CategoryAdapter(Context c, String[] categoryName) {

            super(c, R.layout.category_frame, R.id.category_name, categoryName);
            this.context = c;
            this.rCategoryName = categoryName;
        }

        @NonNull
        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            LayoutInflater inflater = (LayoutInflater) getApplicationContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            View category = inflater.inflate(R.layout.category_frame, parent, false);

            TextView categoryName = category.findViewById(R.id.category_name);
            categoryName.setText(rCategoryName[position]);

            return category;
        }
    }

    public void customToastView(String text){
        LayoutInflater inflater = getLayoutInflater();
        View layout = inflater.inflate(R.layout.toast_custom, (ViewGroup)findViewById(R.id.toast_layout_root));
        TextView textView = layout.findViewById(R.id.textboard);
        textView.setText(text);

        Toast toast = Toast.makeText(getApplicationContext(),text,Toast.LENGTH_SHORT);
        toast.setView(layout);
        toast.show();
    }
}
